"""Composition Root。

責務は3つだけ：ミドルウェアの組立、ルーターの登録、起動処理の呼び出し。
業務ロジック・SQL・HTML生成はここには一切置かない。
"""
import os

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from app.core.config import IS_CLOUD, DEPLOY_MODE, PUBLIC_BASE_URL, ADMIN_TOKEN, VIEW_TOKEN
from app.infrastructure.db.connection import DB_PATH
from app.infrastructure.db.schema import init_db
from app.infrastructure.db.bracket_repair import fix_bracket_slots_on_startup
from app.presentation.auth import add_auth
from app.presentation.onprem_auth import add_onprem_auth
from app.presentation.middleware.store_resolver import add_store_resolver
from app.presentation.middleware.security import add_security_headers
from app.presentation.middleware.m4laps_license import add_m4laps_license

# ルーター（未移行モジュールは旧パスのまま＝互換シム経由で動作）
from app.routers import admin, tournaments
from app.routers.viewer import router as viewer_router
from app.routers.qualifying import router as qualifying_router
from app.presentation.routers.time_attack import router as time_attack_router
from app.routers.bracket import router as bracket_router
from app.routers.racers import router as racers_router
from app.presentation.routers.stores import router as stores_router
from app.presentation.routers.public_entry import router as public_entry_router
from app.presentation.routers.public_misc import router as public_misc_router
from app.presentation.routers.pwa_manifest import router as pwa_manifest_router
from app.presentation.routers.timing_settings import router as timing_settings_router
from app.presentation.routers.preview import (
    router as preview_router,
    admin_router as preview_admin_router,
)
from app.presentation.routers.timing_api import router as timing_api_router

app = FastAPI(title="ミニ四駆レース管理システム", version="1.0.0")

# クラウド版のみ：固定トークン認証（店舗別）を有効化（オンプレ版では無効＝従来挙動）。
# ミドルウェアは「後に追加したものが外側（先に実行）」。店舗リゾルバを認証より外側に
# 置く必要があるため、add_auth を先、add_store_resolver を後に呼ぶ。
add_auth(app)
# オンプレ版のLAN公開時：ONPREM_ADMIN_PIN 設定時のみ /admin をPIN保護（既定は無効＝従来挙動）。
add_onprem_auth(app)
add_store_resolver(app)
# M4LAPSライセンス状態を request.state にセット（クラウドのadmin画面でのみ判定）。
add_m4laps_license(app)
# 最外周（最後に追加＝先に実行）：HTTPS強制とセキュリティヘッダを全応答へ。
add_security_headers(app)

# 監査ログ：結果系（/qualifying/・/bracket/ へのPOST）を1か所で拾って記録する。
# スキャンは件数が多く結果操作ではないため除外。記録失敗はリクエストに影響させない。
@app.middleware("http")
async def _audit_mw(request, call_next):
    response = await call_next(request)
    try:
        path = request.url.path
        if request.method == "POST" and ("/qualifying/" in path or "/bracket/" in path) and "/scan" not in path:
            from app.services import audit_log
            store = getattr(request.state, "store", None)
            skey = (getattr(store, "slug", "") or "default")
            xff = request.headers.get("x-forwarded-for", "")
            ip = (xff.split(",")[0].strip() if xff else (request.client.host if request.client else ""))
            audit_log.record(skey, ip, request.method, path, response.status_code)
    except Exception:
        pass
    return response


# 参加者向けHTML配信（横断フック）：予選・決勝など「観覧ページに載る変更」を伴う
# 更新系リクエストが成功したら、その店舗のHTML書き出しを1か所で予約する。各
# エンドポイントでの schedule_publish() 呼び忘れによる『配信が更新されない』不具合を
# 横断的に防ぐ。デバウンス＋シングルフライトのため多重予約は安全。店舗コンテキストは
# 外周ミドルウェアでは ContextVar がリセット済みのため request.state.store から復元する。
import re as _re_pub
_PUB_TL_RE = _re_pub.compile(r"/tournaments/\d+/(status|edit|edit-final|delete)$")
_PUB_RENAME_RE = _re_pub.compile(r"/tournaments/\d+/entries/\d+/rename-racer$")

def _needs_publish(path: str) -> bool:
    if "/qualifying/" in path or "/bracket/" in path or "/api/timing/apply/" in path:
        return True
    if _PUB_TL_RE.search(path) or _PUB_RENAME_RE.search(path):
        return True
    # 参加者向けHTMLの見た目・待機画面に影響する設定変更（スライドショー・背景・
    # PWAアイコン/manifest・店名・配信設定）。/telop は /api/telop の動的取得のため対象外。
    if "/admin/settings/pwa/" in path or "/admin/settings/store-name/" in path \
       or "/admin/settings/public-html/" in path:
        return True
    if path.endswith("/admin/db/reset"):
        return True
    return False

@app.middleware("http")
async def _publish_mw(request, call_next):
    response = await call_next(request)
    try:
        if request.method in ("POST", "PUT", "PATCH", "DELETE") \
           and response.status_code < 400 and _needs_publish(request.url.path):
            from app.services.publish_scheduler import schedule_publish
            from app.core.store_context import current_store
            store = getattr(request.state, "store", None)
            tok = current_store.set(store)
            try:
                schedule_publish()   # 予約時に現在店舗IDをキャプチャ
            finally:
                current_store.reset(tok)
    except Exception:
        pass
    return response


BASE_DIR = os.path.dirname(__file__)
app.mount("/static", StaticFiles(directory=os.path.join(BASE_DIR, "static")), name="static")

# 複数店舗（クラウド版）：スラッグ付き /static を配信する。
_STATIC_ROOT = os.path.join(BASE_DIR, "static")


@app.get("/{slug}/static/{path:path}")
async def store_static(slug: str, path: str):
    full = os.path.normpath(os.path.join(_STATIC_ROOT, path))
    # ディレクトリトラバーサル防止（_STATIC_ROOT 配下のみ許可）
    if not (full == _STATIC_ROOT or full.startswith(_STATIC_ROOT + os.sep)):
        raise HTTPException(status_code=404)
    if not os.path.isfile(full):
        raise HTTPException(status_code=404)
    return FileResponse(full)


# 賞状背景画像保存先（/static/cert_bg/ で配信されるため別マウント不要）
os.makedirs(os.path.join(BASE_DIR, "static", "cert_bg"), exist_ok=True)

app.include_router(admin.router, prefix="/admin")
app.include_router(qualifying_router, prefix="/admin/tournaments")
app.include_router(time_attack_router, prefix="/admin/tournaments")
app.include_router(bracket_router, prefix="/admin/tournaments")
app.include_router(racers_router, prefix="/admin/racers")
app.include_router(tournaments.router, prefix="/admin/tournaments")
app.include_router(viewer_router, prefix="/view")
app.include_router(stores_router, prefix="/admin/stores")
app.include_router(timing_settings_router, prefix="/admin/timing")
app.include_router(timing_api_router)
app.include_router(pwa_manifest_router)
app.include_router(public_entry_router)
app.include_router(public_misc_router)
# 事前告知ページ：公開（/api/preview/<token>）＋ 管理API（/admin/preview/...）
app.include_router(preview_router)
app.include_router(preview_admin_router, prefix="/admin/preview")


@app.on_event("startup")
async def startup():
    import time as _t
    app.state.started_at = _t.time()
    if IS_CLOUD:
        # 複数店舗化：レジストリ（control.db）を用意し、店舗1（既定店舗）を移行登録。
        from app import registry
        registry.init_registry(default_admin_token=ADMIN_TOKEN, default_view_token=VIEW_TOKEN)
        stores = registry.list_stores(include_disabled=True)
        for st in stores:
            await init_db(st.db_path)
            await fix_bracket_slots_on_startup(st.db_path)
            print(f"[APP] 店舗 init: id={st.id} slug='{st.slug or '(default)'}' "
                  f"name={st.name} db={st.db_path}", flush=True)
        # 参加者向けHTMLを起動時に全店舗ぶん再書き出しする。
        # デプロイ直後に、旧版で書き出された index.html（24時間ゲートJSが
        # 入っていない版）が配信され続けるのを防ぐ（デプロイ＋再起動だけで最新化）。
        async def _republish_all_stores():
            from app.services.public_html import export_current_html
            from app.store_context import current_store
            for st2 in registry.list_stores():
                token = current_store.set(st2)
                try:
                    await export_current_html()
                except Exception as e:
                    print(f"[APP] startup republish error "
                          f"(store={st2.slug or 'default'}): {e}", flush=True)
                finally:
                    current_store.reset(token)
        import asyncio as _aio
        app.state._startup_republish = _aio.create_task(_republish_all_stores())

        # DB自動バックアップ（毎晩03:30 JST・14世代保持）をクラウド版で開始
        from app.services import backup_scheduler
        backup_scheduler.launch()
        print(f"[APP] 起動完了（クラウド版 / 複数店舗 {len(stores)}件 / "
              f"DEPLOY_MODE={DEPLOY_MODE}）"
              f"{' / ' + PUBLIC_BASE_URL if PUBLIC_BASE_URL else ''}", flush=True)
    else:
        # オンプレ版：従来どおり単一DB。
        await init_db()
        await fix_bracket_slots_on_startup()
        print("[APP] 起動完了 → http://localhost:8000/admin/")