"""
参加者向け静的HTML生成・GCSアップロードサービス

- export_current_html(db) : 現在のhost_stateに対応するページを生成してGCSへアップロード
- _get_settings(db)       : app_settings からクラウド設定を取得
- _render_page(url, db)   : viewer の各ルーター関数を直接呼び出してHTMLを生成
- _upload_to_gcs(html, bucket) : GCSへアップロード
"""

from __future__ import annotations
import logging
import re

logger = logging.getLogger(__name__)


async def _get_settings(db) -> dict:
    """app_settings からクラウド設定を取得"""
    result = {}
    keys = ["public_html_enabled", "public_html_gcs_bucket", "public_html_gcp_project"]
    for key in keys:
        async with db.execute(
            "SELECT value FROM app_settings WHERE key=?", (key,)
        ) as cur:
            row = await cur.fetchone()
        result[key] = row["value"] if row else ""
    return result


_logo_cache: dict = {}   # path -> (mtime, data_uri)


def _get_logo_base64() -> str | None:
    """ロゴ画像をBase64エンコードして返す。

    ロゴは起動中ほぼ不変なので、ファイルの更新時刻(mtime)をキーにキャッシュする。
    差し替え時は mtime が変わるため自動的に再読み込みされる。
    （①のデバウンスで書き出し頻度自体は下がったが、読み込みコストはゼロにできる）
    """
    import base64, os
    base = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    for name in ("logo_header.jpg", "logo_header.png"):
        path = os.path.join(base, "app", "static", name)
        if not os.path.exists(path):
            continue
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            mtime = None
        hit = _logo_cache.get(path)
        if hit and hit[0] == mtime:
            return hit[1]
        ext = os.path.splitext(path)[1].lower().lstrip(".")
        mime = "image/jpeg" if ext in ("jpg", "jpeg") else f"image/{ext}"
        with open(path, "rb") as f:
            uri = f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"
        _logo_cache[path] = (mtime, uri)
        return uri
    return None


def _patch_html_for_static(html: str, slug: str = "", is_finalized: bool = False,
                           ta_enabled: bool = False) -> str:
    """
    静的配信用: 全JSを除去し、bracket線描画JS＋有効期限ゲートJSを再注入する。

    有効期限（案①・クライアント側ソフト方式 / 24時間）:
      参加者は QR（/enter）経由でアクセスし、/enter が localStorage に発行時刻を記録する。
      本ページは発行時刻から24時間以内なら10秒ごとに「更新の有無」を確認し、変化があった
      ときだけ反映する（ETag条件付きGETで304が返れば何もしない）。超過すると自動更新を止めて
      「QRを読み直してください」のオーバーレイを表示する。単純な再読込では復帰せず、QR
      （/enter）を読み直すと新たな24時間が始まる。判定は全てブラウザ側で完結するため
      サーバー負荷は増えない（ページ配信は従来どおり nginx の静的配信）。
    """
    import re as _re

    # admin と同一のブラケット・レイアウトJS（window._bracketDrawConnectors を定義する
    # 自己実行関数ブロック）を、全script除去の前に抽出して保持する。
    # これにより参加者向け静的HTMLでも PC版と同一のツリー配置・コネクタ線描画が動作する。
    # ⚠ 本文には注入済みブラケット断片の <script> も存在する。`.*?` が </script> を
    #   跨ぐと「別scriptの開始〜本文HTML〜本命script」まで巻き込んだ巨大マッチになり、
    #   末尾再注入で本文がまるごと複製される（実障害）。(?:(?!</script>).) で
    #   同一 <script> ブロック内に限定し、跨りを構造的に不可能にする。
    bracket_layout_js = ""
    _blm = _re.search(
        r'<script>\s*\(function\(\)\s*\{'
        r'(?:(?!</script>).)*?window\._bracketDrawConnectors'
        r'(?:(?!</script>).)*?\}\)\(\);\s*</script>',
        html, flags=_re.DOTALL
    )
    if _blm:
        bracket_layout_js = _blm.group(0)

    # 名前タップ→予選タイム詳細モーダルのJS（window.openRacerStats を定義）も、
    # 全script除去の前に抽出して保持し、後で再注入する。
    # （上と同じ理由で、同一 <script> ブロック内に限定する）
    racer_stats_js = ""
    _rsm = _re.search(
        r'<script>\s*\(function\(\)\s*\{'
        r'(?:(?!</script>).)*?window\.openRacerStats'
        r'(?:(?!</script>).)*?\}\)\(\);\s*</script>',
        html, flags=_re.DOTALL
    )
    if _rsm:
        racer_stats_js = _rsm.group(0)
        # 公開HTMLは日替わり2語URL（/{token}）で配信されるが、openRacerStats は
        # fetch 先を location.pathname（＝その日替わりトークン）から組み立てており、
        # /{token}/view/tournament/.../stats を叩いて失敗する（他 fetch は /{slug}/... で動作）。
        # ここで base をサーバ既知の正しいプレフィックス（slug有→/{slug}／既定店舗→空）へ固定する。
        _rs_prefix = f"/{slug}" if slug else ""
        racer_stats_js = racer_stats_js.replace(
            r"var base=location.pathname.replace(/\/view\/.*$/,'').replace(/\/$/,'');",
            "var base='%s';" % _rs_prefix,
        )

    # 全<script>タグを除去
    patched = _re.sub(r'<script[^>]*>.*?</script>', '', html, flags=_re.DOTALL)

    # view 画面由来の PWA タグを除去する。参加者向け静的HTMLは view画面のHTMLを
    # 流用しているため、そのままだと <link rel="manifest" href="/{slug}/view/manifest.webmanifest">
    # が残る。iOS で「ホーム画面に追加」すると、この view 用 manifest の start_url(=/{slug}/view/)
    # がアイコンに登録され、アイコンから起動すると view 画面が開いてしまう。
    # ここで view 用を落とし、この後 render_pwa_head_html が注入するレーサー用 manifest
    # (/{slug}/manifest.webmanifest, start_url=/{slug}/enter) だけを残す。
    patched = _re.sub(r'<link[^>]*rel=["\']manifest["\'][^>]*>', '', patched, flags=_re.IGNORECASE)
    patched = _re.sub(r'<meta[^>]*name=["\']theme-color["\'][^>]*>', '', patched, flags=_re.IGNORECASE)
    patched = _re.sub(r'<meta[^>]*name=["\'](?:mobile-web-app-capable|apple-mobile-web-app-capable|apple-mobile-web-app-status-bar-style|apple-mobile-web-app-title)["\'][^>]*>', '', patched, flags=_re.IGNORECASE)
    patched = _re.sub(r'<link[^>]*rel=["\']apple-touch-icon["\'][^>]*>', '', patched, flags=_re.IGNORECASE)

    # ナビボタン非表示を追加（自動更新は下部の expiry スクリプトがJSで制御するため
    # 従来の <meta refresh> は使わない）
    inject = """<style>
/* ナビボタン非表示 */
.v-nav .v-nav-btn{display:none}
#sync-btn{display:none}
/* #5 トーナメント表のレーサー名タップ可（公開HTMLのみ） */
.br-slot[data-entry-id]{cursor:pointer}

/* 最大幅・中央寄せ */
html{overflow-x:hidden}body{padding-top:48px}.v-container{max-width:480px;margin:0 auto!important}

/* 公開HTMLは常に幅480pxの1カラム設計。2カラム化(.v-cols)や左右分割(.hr-grp-cols)の
   解除はビューポート幅900px判定なので、タブレット(幅>900)だと狭い箱に2カラムが
   押し込まれてスケジュール列が潰れる。公開では常時1カラムに固定して全幅で崩さない。 */
.v-cols{grid-template-columns:1fr!important}
.hr-grp-cols{grid-template-columns:1fr!important}

/* レーススケジュールのセル内容を上下中央に。
   既定(baseline)だと行高が変わったときにレーサー名が上寄せになるため。 */
.schedule-table td{vertical-align:middle!important}

/* info-grid: 左=項目名・右=値 の2列行レイアウト */
.info-grid{display:block!important;border:1px solid #2c3e50;border-radius:6px;overflow:hidden}
.info-cell{display:flex!important;align-items:baseline;padding:6px 12px;border-bottom:1px solid #2c3e50}
.info-cell:last-child{border-bottom:none}
.info-label{color:#7f8c8d;font-size:12px;flex:0 0 7em;white-space:nowrap;font-weight:normal}
.info-value{font-size:12px;font-weight:normal;color:#ecf0f1;flex:1}
.info-value.large{font-size:12px;font-weight:bold}

/* entry-grid: 1列 */
.entry-grid{grid-template-columns:1fr!important}
/* bracket: 横スクロールをスマホでも確実に・スムーズに */
.bracket-wrap{overflow-x:auto!important;-webkit-overflow-scrolling:touch}
/* entry-card: 横並び・幅いっぱい。背景をページ背景(#0f1923)と差別化してカードとして見せる
   （!important を付けない＝bracketの進出ハイライト等のインライン背景は上書きしない） */
.entry-card{display:flex!important;flex-direction:row!important;align-items:center;gap:8px;width:100%;padding:8px 12px;box-sizing:border-box;background:#152232;border:1px solid #2c3e50;border-radius:8px}
/* レーサー名: 14px bold・左揃え・省略なし */
.entry-name{font-size:14px!important;font-weight:bold!important;white-space:nowrap;overflow:visible!important;text-overflow:clip!important;flex:1;text-align:left}
/* よみがな: 10px normal */
.entry-yomi{font-size:10px!important;font-weight:normal!important;color:#7f8c8d;white-space:nowrap;flex-shrink:0;margin-top:0!important}
/* 順位バッジ（entry-card 内の先頭span）: 改行・縮小させない */
.entry-card > span:first-child{flex-shrink:0!important;white-space:nowrap!important}
/* お知らせ帯（テロップ）：参加者htmlはナビが fixed(48px) なので貼り付き位置を合わせる */
#m4-telop{top:48px}
</style>
"""
    patched = patched.replace('</head>', inject + '</head>', 1)

    # no-bracketを常に表示（JSが除去されているため）。ただしトーナメント表が
    # 既に注入済み（bracket-html-container が空でない）ときは placeholder を出さない。
    # ※ _inject_bracket_html が先に走ってツリーを注入するため、空コンテナが残って
    #   いる＝トーナメント未作成、と判定できる。
    if '<div id="bracket-html-container"></div>' in patched:
        patched = patched.replace(
            '<div id="no-bracket" style="display:none;',
            '<div id="no-bracket" style="display:block;',
        )

    # /logo をBase64埋め込みに変換
    logo_b64 = _get_logo_base64()
    if logo_b64:
        patched = patched.replace('src="/logo"', f'src="{logo_b64}"')

    # 有効期限ゲート（24時間）＋自動更新（更新検知時のみ反映）スクリプト
    _slug_key = (slug or "default")
    # 失効時の遷移先。素の /enter は「QRを踏んだ」扱いで再発行されてしまうため、
    # 発行しない ?src=expired を必ず付ける。
    _enter_url = (f"/{slug}/enter?src=expired" if slug else "/enter?src=expired")
    _telop_url = (f"/{slug}/api/telop" if slug else "/api/telop")
    # ゲートAPIは全て /enter?api=... で呼ぶ（/enter は QR が動く＝nginx が確実に中継している）
    _pfx_e = (f"/{slug}" if slug else "")
    _status_url = f"{_pfx_e}/enter?api=status"
    _handoff_url = f"{_pfx_e}/enter?api=handoff"
    _manifest_url = f"{_pfx_e}/enter?api=manifest"
    _content_url = f"{_pfx_e}/enter?api=content"
    _events_url = f"{_pfx_e}/enter?api=events"   # SSE（即時push）。失敗時はポーリングにフォールバック
    _raceorder_url = f"{_pfx_e}/enter?api=raceorder"   # アクティブ起点の「次のレースまで」巡回順
    _history_url = (f"/{slug}/api/history" if slug else "/api/history")
    patched = patched.replace("__HISTORYURL__", _history_url)
    _races_url = (f"/{slug}/api/races" if slug else "/api/races")
    patched = patched.replace("__RACESURL__", _races_url)
    # 参加者向け TA（ラップタイム）画面の入口URL（観覧期限バッジの代わりに下部へ表示）
    _ta_url = (f"/{slug}/api/ta" if slug else "/api/ta")
    # アクセス統計用：表示中の大会ID（/view/tournament/<id> リンクから抽出。トップ等は0）
    import re as _re_tid
    _mtid = _re_tid.search(r"/view/tournament/(\d+)", html)
    _tid = _mtid.group(1) if _mtid else "0"
    expiry_script = """<script>
(function(){
  window.__M4_PUBLIC__ = true;   // #5 公開HTML判定（トーナメント表のレーサー名タップ→成績モーダル）
  window.__M4_FINALIZED__ = __M4FINAL__;   // 結果確定済みなら「次のレースまで」案内を抑止
  window.__M4_TA_ON__ = __M4TA__;   // 連動型ラップタイマーM4LAPSが有効な店舗のみ true（ラップタイムボタン表示可否）
  var KEY = "m4_pub_issued___SLUGKEY__";
  var TTL = 24*60*60*1000;          // 24時間（サーバーの日境界=翌09:00に合わせる。正確な失効はサーバー判定/scheduleDeadline）
  var CHECK_MS = 10000;             // 10秒ごとに「更新の有無」だけ確認する（変化なしはETagで304＝最軽量）
  var ENTER = "__ENTERURL__";
  var STATUS = "__STATUSURL__";
  var HANDOFF = "__HANDOFFURL__";
  var MANIFEST = "__MANIFESTURL__";
  var CONTENT = "__CONTENTURL__";   // 観覧内容（サーバーでクッキー検証してから返す）
  var EVENTS = "__EVENTSURL__";     // SSE（即時push）。届かない環境ではポーリングにフォールバック
  var handoffDone = false;

  function issued(){ try { return parseInt(localStorage.getItem(KEY)||"0",10)||0; } catch(e){ return 0; } }
  function expired(){ var t=issued(); return (!t) || (Date.now()-t > TTL); }
  function isStandalone(){
    try {
      return (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches)
             || window.navigator.standalone === true;
    } catch(e){ return false; }
  }
  function evict(){
    // サーバーが失効と判定：ページ内容ごと破棄し、サーバー描画の失効ページへ。
    // （オーバーレイだけだと開発者ツールで剥がせるため、DOMから消す）
    try { localStorage.setItem(KEY, "0"); } catch(e){}
    try { location.replace(ENTER); } catch(e){ showOverlay(); }
  }
  var deadlineTimer = null;
  function scheduleDeadline(expiresAt){
    // 期限の絶対時刻ちょうどに /enter へ遷移する保険タイマー。
    // バックグラウンドでポーリングが止められていても、復帰した瞬間に発火する。
    // （端末時計がずれていても、遷移先の /enter がサーバー時刻で再判定するので安全）
    try {
      if(deadlineTimer){ clearTimeout(deadlineTimer); deadlineTimer = null; }
      if(!expiresAt) return;
      var ms = expiresAt * 1000 - Date.now() + 1500;
      if(ms < 0) ms = 0;
      if(ms > 2147000000) ms = 2147000000;
      deadlineTimer = setTimeout(evict, ms);
    } catch(e){}
  }
  function showDeadline(expiresAt){
    // 観覧期限バッジの代わりに「ラップタイム(TA)」入口ボタンを下部中央に常時表示。
    // （期限の失効処理は scheduleDeadline() が担うので、ここは表示のみ）
    try {
      if(!window.__M4_TA_ON__) return;   // M4LAPS無効の店舗はボタンを出さない
      if(document.getElementById('m4-ta-btn')) return;   // 既に設置済みなら何もしない
      var a = document.createElement('a');
      a.id = 'm4-ta-btn';
      a.href = "__TAURL__";
      a.textContent = '📊 ラップタイム';
      a.style.cssText = 'position:fixed;left:50%;bottom:12px;transform:translateX(-50%);z-index:97;'
        + 'background:#2d9bf0;color:#fff;font-size:13px;font-weight:bold;padding:9px 18px;border-radius:999px;'
        + 'font-family:sans-serif;letter-spacing:.02em;text-decoration:none;'
        + 'box-shadow:0 2px 10px rgba(0,0,0,.35);white-space:nowrap;';
      document.body.appendChild(a);
    } catch(e){}
  }
  function attachHandoffManifest(){
    // iOS PWA 用：有効な間に manifest を「引き継ぎトークン付き」に差し替える。
    // ホーム画面追加時にこの manifest が読まれ、PWA はブラウザと同じ期限を引き継ぐ。
    if(handoffDone) return;
    fetch(HANDOFF, {cache:'no-store'}).then(function(r){ return r.ok ? r.json() : null; }).then(function(j){
      if(!j || !j.ok || !j.h) return;
      var link = document.querySelector('link[rel="manifest"]');
      if(!link){ link = document.createElement('link'); link.rel = 'manifest'; document.head.appendChild(link); }
      link.href = MANIFEST + (MANIFEST.indexOf('?') >= 0 ? '&' : '?') + 'h=' + encodeURIComponent(j.h);
      handoffDone = true;
    }).catch(function(){});
  }
  function showOverlay(){
    if(document.getElementById("m4-expired")) return;
    var ov=document.createElement("div");
    ov.id="m4-expired";
    ov.style.cssText="position:fixed;inset:0;z-index:99999;background:rgba(20,24,33,.96);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:24px;font-family:sans-serif;";
    var head='<div style="font-size:22px;font-weight:bold;margin-bottom:14px">観覧の有効期限が切れました</div>';
    // 旧実装のPWA向け「更新」ボタン（/enter?src=rescan で無条件延長）はサーバー側
    // 24時間ゲート導入に伴い廃止。PWA・ブラウザとも「最新QRの再スキャン」に統一する。
    var pwaNote = isStandalone()
      ? '<div style="margin-top:14px;font-size:12px;opacity:.75;line-height:1.7">ホーム画面アイコンの有効期限も切れています。<br>ブラウザで会場のQRコードを読み直し、必要なら「ホーム画面に追加」をやり直してください。</div>'
      : '';
    ov.innerHTML=head
      +'<div style="font-size:15px;line-height:1.7;margin-bottom:22px;opacity:.9">会場のQRコードを<br>もう一度スキャンしてください。</div>'
      +'<div style="display:inline-block;background:#2c3e50;color:#cfd8e3;padding:12px 22px;border-radius:8px;font-size:15px;font-weight:bold;line-height:1.6">受付時間内にQRコードを再スキャンすると<br>当日分（翌8:59まで）の観覧を再開できます</div>'
      +pwaNote;
    document.body.appendChild(ov);
  }

  if(expired()){ showOverlay(); return; }

  // ---- 操作中フラグ（操作中はリロードを保留してチカチカ・割り込みを防ぐ） ----
  var lastInteract = 0;
  function touch(){ lastInteract = Date.now(); }
  ['touchstart','touchmove','pointerdown','scroll','keydown','wheel'].forEach(function(ev){
    window.addEventListener(ev, touch, {passive:true});
  });
  function isBusy(){
    // 直近1.2秒以内に操作があれば「操作中」とみなす
    if(Date.now() - lastInteract < 1200) return true;
    // プルダウン（マイレーサー選択）が開いている/フォーカス中なら保留
    var sel = document.getElementById('m4-racer-select');
    if(sel && document.activeElement === sel) return true;
    // テキスト入力等にフォーカス中なら保留
    var ae = document.activeElement;
    if(ae && (ae.tagName === 'SELECT' || ae.tagName === 'INPUT' || ae.tagName === 'TEXTAREA')) return true;
    return false;
  }

  // ---- 更新検知（ETag優先・無ければ本文ハッシュ） ----
  var lastTag = null;     // 直近に確認したETag
  var lastHash = null;    // ETagが無い環境用の本文ハッシュ
  var pendingReload = false;

  function hashStr(s){
    // 軽量な文字列ハッシュ（FNV-1a 32bit）。暗号用途ではなく変化検出のみ。
    var h = 0x811c9dc5;
    for(var i=0;i<s.length;i++){ h ^= s.charCodeAt(i); h = (h + ((h<<1)+(h<<4)+(h<<7)+(h<<8)+(h<<24))) >>> 0; }
    return h >>> 0;
  }

  var pendingHtml = null;
  var lastStruct = null;  // トーナメント構造の世代印（生成・再生成・削除で変化）

  // 取得HTMLから「トーナメント表の骨格」だけを抜き出して世代印を作る。
  // 中身（勝者名など）ではなく“枠組み”の変化を捉えたいので、
  //  - トーナメント表要素（.br-round）の個数
  //  - 各ラウンド・各グループの「スロット数」の並び
  // をつないだ文字列とする。結果入力だけでは変わらず、
  // 生成・再生成・削除でのみ変わる（=フルリロードすべき瞬間）。
  //
  // ⚠ 決勝ブラケット(.br-round)だけでなく、予選スケジュール(.schedule-table)の
  //    生成・再生成・削除も世代印に含める。ポイント制/先着順の予選は .br-round を
  //    持たないため、これを見ないと「0レース→Nレース生成」が同一世代と誤判定され、
  //    フルリロードされず部分差し替えになってレイアウトが崩れる（F5で直る症状）。
  //    表数・行数は結果入力では変わらないので、軽い部分更新は従来どおり維持される。
  function structSig(root){
    try {
      // --- 決勝ブラケットの骨組み ---
      var rounds = root.querySelectorAll('.br-round');
      var bracketSig;
      if(!rounds || rounds.length === 0){
        bracketSig = 'no-bracket';   // トーナメント表がまだ無い状態も1世代として区別
      } else {
        var parts = [];
        rounds.forEach(function(r){
          var g = [];
          r.querySelectorAll('.br-group').forEach(function(grp){
            g.push(grp.querySelectorAll('.br-slot').length);
          });
          parts.push(g.join('-'));
        });
        bracketSig = parts.join('|');
      }
      // --- 予選スケジュールの骨組み（生成・再生成・削除で変化） ---
      var schedTables = root.querySelectorAll('.schedule-table').length;
      var schedRows   = root.querySelectorAll('.schedule-table tr.race-row').length;
      return bracketSig + '#sch:' + schedTables + ',' + schedRows;
    } catch(e){
      return 'err';
    }
  }

  // 取得済みHTMLから .v-container の中身だけを差し替える（フルリロードしない）。
  // 予選（全形式）・決勝のいずれも .v-container 配下にレンダリングされるため一律に効く。
  // 差し替え後にブラケット線の再描画とマイレーサーの再適用を行う。
  // 想定外（構造が取れない/解析失敗）のときは安全側で location.reload() にフォールバック。
  function applyPartial(newHtml){
    try {
      var doc = new DOMParser().parseFromString(newHtml, 'text/html');
      var fresh = doc.querySelector('.v-container');
      var live  = document.querySelector('.v-container');
      if(!fresh || !live){ location.reload(); return; }
      // マイレーサー選択・スクロール位置を保持
      var selOld = document.getElementById('m4-racer-select');
      var selVal = selOld ? selOld.value : null;
      var sx = window.scrollX, sy = window.scrollY;
      // 更新箇所だけ差し替え。
      // fresh は DOMParser がフルHTMLとして（初回ロードと同じ解析器で）正しく解析済みのノード。
      // 旧実装の live.innerHTML = fresh.innerHTML は「一度文字列化して断片として再パース」するため、
      // 崩れ気味のHTMLでは文書パースと断片パースの自動補正が食い違い、standings-table 等の
      // クラス付与やテーブル構造が失われてスタイルが外れることがある。
      // 解析済みノードを直接移植して、初回ロードと同一構造を保つ。
      try {
        while(live.firstChild){ live.removeChild(live.firstChild); }
        var _kids = Array.prototype.slice.call(fresh.childNodes);
        for(var _i=0; _i<_kids.length; _i++){
          live.appendChild(document.importNode(_kids[_i], true));
        }
      } catch(e){
        live.innerHTML = fresh.innerHTML;   // 念のためのフォールバック
      }
      // head の <style>（extra_style 等）も fresh 文書に合わせて補正しておく（欠落・不整合時の保険）。
      // data-m4part 印の付いたものだけ毎回入れ替えるので無制限には増えない。
      try {
        var _fh = (doc.head ? doc.head.querySelectorAll('style') : null);
        if(_fh && _fh.length){
          var _lh = document.head;
          var _old = _lh.querySelectorAll('style[data-m4part="1"]');
          for(var _o=0; _o<_old.length; _o++){ _old[_o].remove(); }
          for(var _s=0; _s<_fh.length; _s++){
            var _st = document.createElement('style');
            _st.setAttribute('data-m4part','1');
            _st.textContent = _fh[_s].textContent;
            _lh.appendChild(_st);
          }
        }
      } catch(e){}
      // 決勝ツリーの二重表示ガード（差し替えで重複が入っても最初の1つだけ残す）
      if(typeof window._m4DedupBracket === 'function'){
        try { window._m4DedupBracket(); } catch(e){}
      }
      // ブラケット線を再描画（決勝・ヒート予選の全 .bracket-outer が対象）
      if(typeof window._bracketDrawConnectors === 'function'){
        try { window._bracketDrawConnectors(); } catch(e){}
      }
      // 線描画後にマイレーサーを再適用＋選択・スクロール復元
      setTimeout(function(){
        if(typeof window._m4Reapply === 'function'){
          try { window._m4Reapply(); } catch(e){}
        }
        var sel2 = document.getElementById('m4-racer-select');
        if(sel2 && selVal != null){ try { sel2.value = selVal; } catch(e){} }
        try { window.scrollTo(sx, sy); } catch(e){}
      }, 120);
    } catch(e){
      location.reload();   // 想定外は全リロードで確実に最新化
    }
  }

  function applyWhenIdle(newHtml){
    pendingReload = true;
    pendingHtml = newHtml;
    (function wait(){
      if(expired()){ showOverlay(); return; }
      if(!isBusy()){
        var h = pendingHtml; pendingHtml = null; pendingReload = false;
        applyPartial(h);
        return;
      }
      setTimeout(wait, 600);   // 操作が落ち着くまで待ってから反映
    })();
  }

  function check(){
    if(window.__m4ModalOpen){ return; }   // レイアウト/タイスケ/備考の観覧中は自動更新を止める
    if(expired()){ showOverlay(); return; }
    if(pendingReload) return;  // 反映待ち中は多重チェックしない

    // ---- サーバー側24時間ゲート（正の判定はサーバー時刻・サーバー署名） ----
    // 失効(expired)・不正(invalid)・未発行(none)なら自動更新を止めてオーバーレイ。
    // 通信失敗時のみ従来のローカル判定にフォールバック（オフラインで即失効させない）。
    fetch(STATUS, {cache:'no-store'}).then(function(r){ return r.json(); }).then(function(j){
      if(j && j.gate && j.state !== 'valid'){
        evict();
        return;
      }
      if(j && j.gate){ showDeadline(j.expires_at || 0); scheduleDeadline(j.expires_at || 0); }
      attachHandoffManifest();
      fetchContent();
    }).catch(function(){
      if(expired()){ showOverlay(); return; }
      fetchContent();
    });
  }

  function fetchContent(){
    if(pendingReload) return;
    var headers = {};
    if(lastTag) headers['If-None-Match'] = lastTag;

    fetch(CONTENT, {
      method: 'GET',
      cache: 'no-store',
      headers: headers
    }).then(function(res){
      if(res.status === 401 || res.status === 403){ evict(); return null; }
      if(res.status === 304){
        // 変更なし（ETagが一致）。ボディも返らないため最も軽い。
        return null;
      }
      // 200が返ったらETagの値は信用せず、必ず本文ハッシュで実体の変化を確認する。
      // （ETagが内容更新を正しく反映しない配信構成があるため、中身で判定するのが確実）
      var tag = res.headers.get('ETag');
      return res.text().then(function(txt){
        var h = hashStr(txt);
        if(lastHash === null){
          // 初回：基準値として記録（ETagも保存して次回は304を狙う）
          lastHash = h;
          lastTag = tag;
          lastStruct = structSig(document);  // 現在表示中の構造世代を基準化
          return;
        }
        if(h !== lastHash){
          lastHash = h;
          lastTag = tag;

          // 取得HTMLの「トーナメント構造の世代印」を算出
          var freshDoc = new DOMParser().parseFromString(txt, 'text/html');
          var newStruct = structSig(freshDoc);
          if(lastStruct === null){ lastStruct = structSig(document); }

          // トーナメントの生成・再生成・削除（骨組みの世代が変化）を検出したら、
          // 部分更新では枠組みが食い違って崩れるため、フルリロードで確実に最新化する。
          // （no-bracket ⇔ bracket の遷移も構造変化として拾う）
          if(newStruct !== lastStruct){
            lastStruct = newStruct;
            if(expired()){ showOverlay(); return; }  // 追従停止中はリロードせず従来どおり
            location.reload();
            return;
          }

          // 構造は同じ（＝勝者などの中身だけ変化）→ 従来どおり軽い部分更新
          applyWhenIdle(txt);
        } else {
          // 中身は同じ。ETagだけ更新しておき次回の304判定に使う
          lastTag = tag;
        }
      });
    }).catch(function(){ /* 一時的な通信失敗は無視して次回再試行 */ });
  }

  // ---- ポーリング（SSE断時のフォールバック。SSE接続中は間隔を緩める）----
  var FAST_MS = CHECK_MS;   // SSE未接続/断：10秒（確実な更新手段）
  var SLOW_MS = 60000;      // SSE接続中：60秒の安全ハートビート（取りこぼし保険）
  var pollTimer = null;
  function startPolling(ms){
    if(pollTimer){ clearInterval(pollTimer); }
    pollTimer = setInterval(check, ms);
  }

  // 初回に基準値（ETag/ハッシュ）を取得してから、定期チェックを開始する
  check();
  startPolling(FAST_MS);
  // バックグラウンドからの復帰・戻る操作でのbfcache復元時は、次のポーリングを待たず即判定
  document.addEventListener('visibilitychange', function(){ if(!document.hidden) check(); });
  window.addEventListener('pageshow', function(ev){ if(ev.persisted) check(); });

  // ---- SSE（Server-Sent Events）による即時push ----
  // アドミンが更新した瞬間にサーバーから合図が来て、その場で check()/テロップ更新を走らせる。
  // ・接続直後に届く 'ready' を受信できた時だけポーリングを緩める（＝プロキシがバッファ
  //   していない＝pushが実際に流れている確証。バッファ環境では ready が来ないので
  //   10秒ポーリングのまま＝壊れない）。
  // ・切断/非対応/接続不可では onerror で 10秒ポーリングへ戻す（EventSource は自動再接続）。
  (function initSSE(){
    if(typeof EventSource === 'undefined' || !EVENTS){ return; }   // 非対応→ポーリング継続
    var live = false;
    function goLive(){ if(!live){ live = true; startPolling(SLOW_MS); } }
    function goPoll(){ live = false; startPolling(FAST_MS); }
    var es;
    try { es = new EventSource(EVENTS); } catch(e){ return; }
    es.addEventListener('ready',  function(){ goLive(); });
    es.addEventListener('update', function(){ goLive(); check(); });
    es.addEventListener('telop',  function(){ goLive(); if(window.__m4TelopPoll){ try { window.__m4TelopPoll(); } catch(e){} } });
    es.onerror = function(){ goPoll(); };   // 確立できない環境ではポーリングが実質の更新手段
  })();
})();
</script>""".replace("__SLUGKEY__", _slug_key).replace("__ENTERURL__", _enter_url).replace("__STATUSURL__", _status_url).replace("__HANDOFFURL__", _handoff_url).replace("__MANIFESTURL__", _manifest_url).replace("__CONTENTURL__", _content_url).replace("__EVENTSURL__", _events_url).replace("__TAURL__", _ta_url).replace("__M4FINAL__", "true" if is_finalized else "false").replace("__M4TA__", "true" if ta_enabled else "false")

    # bracket レイアウト＋線描画JSを再注入（admin と同一ロジックを保持したものを使用）。
    # connector_js 内で window._bracketDrawConnectors と init() が定義され、ページ内の
    # 全 .bracket-outer（決勝・予選ヒート）のグループ絶対配置とコネクタ線描画を行う。
    if bracket_layout_js:
        redraw_script = bracket_layout_js + """<script>
/* 決勝トーナメントの二重表示ガード。
   決勝ページ（#bracket-html-container あり）でだけ働き、
   万一ツリー(.br-wrap)が複数出ても「上＝最初の1つ」だけを残して他は除去する。
   ヒート予選の複数ブラケットは別コンテナ(#viewer-ht/hr-bracket-*)なので影響しない。 */
window._m4DedupBracket = function(){
  try {
    var cs = document.querySelectorAll('#bracket-html-container');
    if (!cs.length) return;                       // 決勝ページ以外は何もしない
    for (var j = cs.length - 1; j >= 1; j--){ if (cs[j] && cs[j].remove) cs[j].remove(); }
    var c = cs[0];
    // 決勝ページの正しいツリーは c 内の最初の1つだけ。外にある/2つ目以降は除去。
    document.querySelectorAll('.br-wrap').forEach(function(w){ if (!c.contains(w) && w.remove) w.remove(); });
    var ws = c.querySelectorAll('.br-wrap');
    for (var i = ws.length - 1; i >= 1; i--){ if (ws[i] && ws[i].remove) ws[i].remove(); }
    // ⚡ M4LAPS 節・🏆 決勝進出レーサー 節も、決勝表(.br-wrap)と同様に
    // 部分更新のタイミングで二重化することがあるため、先頭の1つだけ残す。
    ['m4-records-sec','m4-laps-sec','m4-finalists-sec'].forEach(function(id){
      var es = document.querySelectorAll('#' + id);
      for (var k = es.length - 1; k >= 1; k--){ if (es[k] && es[k].remove) es[k].remove(); }
    });
  } catch(e){}
};
window.addEventListener('load', function(){
  setTimeout(function(){
    if (typeof window._m4DedupBracket === 'function') { window._m4DedupBracket(); }
    if (typeof window._bracketDrawConnectors === 'function') { window._bracketDrawConnectors(); }
  }, 250);
});
</script>"""
    else:
        redraw_script = ""
    my_racer_script = """<script>
/* ===== マイレーサー フォーカス機能（複数選択対応） ===== */
(function(){
  var SLUG_KEY = '__SLUGKEY__';
  var LS_KEY = 'm4_my_racers_' + SLUG_KEY;

  /* ---------- 「次のレースまで」＝adminアクティブ起点の巡回順（サーバ算出） ----------
     サーバ(/enter?api=raceorder)が、アクティブレースを起点にGW自動遷移と同じ順で
     未確定レースを並べた配列を返す。order[i] に出るレーサーは「次のレースまで i レース」
     （i=0=あなたの番／スキップされた組は末尾に回る）。
     アクティブ未設定(active:false)や名前が見つからない時は null を返し、
     呼び出し側は従来のDOM文書順の数値へフォールバックする。 */
  var RACEORDER = '__RACEORDERURL__';
  window.__M4_RACE_ORDER__ = window.__M4_RACE_ORDER__ || null;
  var _roRaw = null;
  function serverRaceCount(name){
    var ro = window.__M4_RACE_ORDER__;
    if(!ro || !ro.active || !ro.order) return null;
    for(var i = 0; i < ro.order.length; i++){
      var ns = ro.order[i].names || [];
      for(var j = 0; j < ns.length; j++){ if(ns[j] === name) return i; }
    }
    return null;   /* アクティブ中だが未確定レースに居ない＝走行済み/敗退等→DOM値へ */
  }
  function mkCountResult(name, domBefore){
    var sc = serverRaceCount(name);
    var n = (sc != null) ? sc : domBefore;   /* アクティブ有→巡回順 / 無→DOM文書順 */
    return n === 0 ? { text: 'あなたの番です', urgency: 0 }
                   : { text: '次のレースまで' + n + 'レース', urgency: (n === 1 ? 1 : 2) };
  }
  function pollRaceOrder(){
    try{
      fetch(RACEORDER, {cache:'no-store'}).then(function(r){ return r.ok ? r.json() : null; })
        .then(function(j){
          if(!j) return;
          var raw = JSON.stringify(j);
          if(raw === _roRaw) return;          /* 変化なし→再描画しない */
          _roRaw = raw;
          window.__M4_RACE_ORDER__ = j;
          try{ if(window._m4Reapply) window._m4Reapply(); }catch(e){}
        }).catch(function(){});
    }catch(e){}
  }

  /* ---------- 五十音（あいうえお）比較 ---------- */
  var _collator = (typeof Intl !== 'undefined' && Intl.Collator) ? new Intl.Collator('ja') : null;
  function kanaCompare(a, b){
    var ay = a.yomi || a.name, by = b.yomi || b.name;
    if(_collator) return _collator.compare(ay, by);
    return ay < by ? -1 : (ay > by ? 1 : 0);
  }

  /* ---------- エスケープ ---------- */
  function escHtml(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  function escAttr(s){ return escHtml(s).replace(/"/g,'&quot;'); }

  /* ---------- localStorage（配列で保存） ---------- */
  function getMyRacers(){
    try{
      var v = localStorage.getItem(LS_KEY);
      var arr = v ? JSON.parse(v) : [];
      return Array.isArray(arr) ? arr : [];
    }catch(e){ return []; }
  }
  function setMyRacers(arr){ try{ localStorage.setItem(LS_KEY, JSON.stringify(arr)); }catch(e){} }
  function clearMyRacers(){ try{ localStorage.removeItem(LS_KEY); }catch(e){} }
  function toggleRacer(name, yomi){
    var list = getMyRacers();
    var idx = list.findIndex(function(r){ return r.name === name; });
    if(idx >= 0){ list.splice(idx, 1); }
    else { list.push({ name: name, yomi: yomi || '' }); }
    setMyRacers(list);
  }

  /* ---------- エントリー名（＋よみ）一覧を収集し、あいうえお順で返す ---------- */
  function collectNamesWithYomi(){
    var map = {};   /* name -> yomi */
    var order = [];
    function add(name, yomi){
      if(!name) return;
      if(!(name in map)){ map[name] = yomi || ''; order.push(name); }
      else if(yomi && !map[name]){ map[name] = yomi; }
    }
    document.querySelectorAll('.entry-card').forEach(function(card){
      var n = card.querySelector('.entry-name');
      if(!n) return;
      var t = n.textContent.trim();
      var y = card.querySelector('.entry-yomi');
      add(t, y ? y.textContent.trim() : '');
    });
    document.querySelectorAll('.entry-name').forEach(function(el){ add(el.textContent.trim(), ''); });
    document.querySelectorAll('.rr-name').forEach(function(el){ add(el.textContent.trim(), ''); });
    document.querySelectorAll('.br-slot-name').forEach(function(el){ add(el.textContent.trim(), ''); });
    var list = order.map(function(n){ return { name: n, yomi: map[n] }; });
    list.sort(kanaCompare);
    return list;
  }

  /* ---------- 選択パネルの表示位置 ---------- */
  function positionPanel(){
    var panel = document.getElementById('m4-racer-panel');
    var toggleBtn = document.getElementById('m4-racer-toggle');
    if(!panel || !toggleBtn) return;
    var r = toggleBtn.getBoundingClientRect();
    var w = Math.max(r.width, 220);
    var vw = window.innerWidth || document.documentElement.clientWidth;
    var left = Math.round(r.left);
    if(left + w > vw - 8){ left = Math.max(8, vw - w - 8); }
    panel.style.left = left + 'px';
    panel.style.top = Math.round(r.bottom + 4) + 'px';
    panel.style.width = Math.round(w) + 'px';
  }

  /* ---------- 選択パネル（チェックボックス一覧・あいうえお順） ---------- */
  function buildPanel(){
    var list = collectNamesWithYomi();
    var selNames = getMyRacers().map(function(r){ return r.name; });
    var panel = document.getElementById('m4-racer-panel');
    if(!panel){
      panel = document.createElement('div');
      panel.id = 'm4-racer-panel';
      document.body.appendChild(panel);
    }
    panel.style.cssText = 'display:none;position:fixed;z-index:9001;background:#0f4d2a;color:#fff;'
      + 'border:1px solid rgba(255,255,255,.3);border-radius:6px;max-height:60vh;overflow-y:auto;'
      + 'box-shadow:0 4px 14px rgba(0,0,0,.4);min-width:200px;max-width:90vw;padding:4px;box-sizing:border-box;';
    var html = '';
    if(list.length === 0){
      html = '<div style="padding:8px;font-size:12px;">レーサーが見つかりません</div>';
    } else {
      list.forEach(function(item){
        var checked = selNames.indexOf(item.name) >= 0 ? 'checked' : '';
        html += '<label style="display:flex;align-items:center;gap:6px;padding:6px 8px;font-size:13px;'
          + 'cursor:pointer;border-bottom:1px solid rgba(255,255,255,.15);">'
          + '<input type="checkbox" value="' + escAttr(item.name) + '" data-yomi="' + escAttr(item.yomi) + '" '
          + checked + ' style="width:16px;height:16px;flex:none;">'
          + '<span>' + escHtml(item.name) + '</span></label>';
      });
    }
    panel.innerHTML = html;
    panel.querySelectorAll('input[type=checkbox]').forEach(function(cb){
      cb.addEventListener('change', function(){
        toggleRacer(cb.value, cb.getAttribute('data-yomi') || '');
        applyAll();
        buildPanel();               /* チェック状態を再反映 */
        positionPanel();
        document.getElementById('m4-racer-panel').style.display = 'block';
      });
    });
  }

  function togglePanel(){
    buildPanel();
    var panel = document.getElementById('m4-racer-panel');
    if(!panel) return;
    var isOpen = panel.style.display === 'block';
    if(isOpen){ panel.style.display = 'none'; }
    else { positionPanel(); panel.style.display = 'block'; }
  }

  /* パネル外タップで閉じる */
  document.addEventListener('click', function(e){
    var panel = document.getElementById('m4-racer-panel');
    var toggleBtn = document.getElementById('m4-racer-toggle');
    if(!panel || panel.style.display !== 'block') return;
    if(panel.contains(e.target) || (toggleBtn && toggleBtn.contains(e.target))) return;
    panel.style.display = 'none';
  });
  window.addEventListener('resize', function(){
    var panel = document.getElementById('m4-racer-panel');
    if(panel && panel.style.display === 'block') positionPanel();
  });

  /* ---------- 選択バー（トグルボタン＋✕） ---------- */
  function renderBanner(selected){
    /* 待機画面では選択バーを表示しない */
    if(document.querySelector('.v-waiting')){
      var ex = document.getElementById('m4-my-banner');
      if(ex){ ex.remove(); }
      var pnl = document.getElementById('m4-racer-panel');
      if(pnl){ pnl.remove(); }
      var pb0 = document.getElementById('m4-position-banner');
      if(pb0){ pb0.remove(); }
      document.body.style.paddingTop = '';
      return;
    }
    var b = document.getElementById('m4-my-banner');
    var _slot = document.getElementById('m4-picker-slot');
    if(!b){
      b = document.createElement('div');
      b.id = 'm4-my-banner';
      if(_slot){
        b.style.cssText = 'display:flex;align-items:center;gap:6px;flex:1;min-width:0;'
          + 'background:#1a6e3c;color:#fff;border-radius:6px;'
          + 'padding:3px 6px;font-size:12px;font-weight:bold;box-sizing:border-box;';
        _slot.appendChild(b);
      } else {
        b.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9000;background:#1a6e3c;color:#fff;'
          + 'display:flex;align-items:center;gap:8px;'
          + 'padding:6px 10px;font-size:13px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,.4);'
          + 'max-width:480px;margin:0 auto;box-sizing:border-box;';
        document.body.appendChild(b);
        document.body.style.paddingTop = '44px';
      }
    }

    var count = selected.length;
    var label = count > 0 ? ('👤 選択中（' + count + '名）▾') : '👤 レーサーを選択 ▾';
    var btnStyle = 'flex:1;min-width:0;background:#0f4d2a;color:#fff;border:1px solid rgba(255,255,255,.3);'
      + 'border-radius:4px;padding:4px 6px;font-size:13px;font-weight:bold;cursor:pointer;text-align:left;'
      + 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
    var clearStyle = 'background:rgba(255,255,255,.2);border:none;color:#fff;'
      + 'border-radius:4px;padding:4px 10px;font-size:12px;cursor:pointer;white-space:nowrap;';
    b.innerHTML = '<button type="button" id="m4-racer-toggle" style="' + btnStyle + '">' + escHtml(label) + '</button>'
      + '<button type="button" onclick="m4ClearMyRacer()" style="' + clearStyle + '">✕</button>';

    var toggleBtn = document.getElementById('m4-racer-toggle');
    toggleBtn.addEventListener('click', function(e){
      e.stopPropagation();
      togglePanel();
    });
  }

  /* ---------- ハイライト（エントリーカード・複数対応） ---------- */
  function applyEntryHighlight(names){
    var cards = document.querySelectorAll('.entry-card');
    if(cards.length === 0) return;
    cards.forEach(function(card){
      var n = card.querySelector('.entry-name');
      if(!n) return;
      var match = names.indexOf(n.textContent.trim()) >= 0;
      if(match){
        card.style.setProperty('background', 'rgb(230,126,34)', 'important');
        card.style.setProperty('border', '2px solid rgb(160,80,15)', 'important');
        card.style.setProperty('color', '#ffffff', 'important');
        card.style.boxShadow = '0 0 0 2px rgba(230,126,34,.6)';
        card.style.opacity = '1';
        n.style.setProperty('background', 'transparent', 'important');
        n.style.setProperty('color', '#ffffff', 'important');
        n.style.fontWeight = 'bold';
      } else {
        card.style.removeProperty('border');
        card.style.removeProperty('background');
        card.style.removeProperty('color');
        card.style.boxShadow = '';
        card.style.opacity = '';
        n.style.removeProperty('background');
        n.style.removeProperty('color');
        n.style.fontWeight = '';
      }
    });
  }

  /* ---------- 出走順の色 ---------- */
  function urgencyColor(u){
    if(u === 3) return 'linear-gradient(135deg,#b8860b 0%,#f6c744 50%,#b8860b 100%)';   /* 優勝 */
    if(u === 4) return 'linear-gradient(135deg,#1f6fb2 0%,#2ecc71 50%,#1f6fb2 100%)';    /* 入賞 */
    if(u === 0) return 'rgb(200,40,40)';     /* あなたの番 */
    if(u === 1) return 'rgb(210,140,30)';    /* あと1レース */
    return '#154360';                        /* 通常 */
  }

  /* ---------- 1レーサー分の出走ステータスを計算（ハイライトも同時に適用） ---------- */
  function computeStatusForName(name, isHeatQual){
    /* 表彰台チェック（本戦のみ・ヒート予選ページでは判定しない） */
    if(!isHeatQual){
      var podRank = 0;
      [['.br-champion', '.br-champion-name', 1],
       ['.br-runner-up', '.br-runner-up-name', 2],
       ['.br-third-pod', '.br-third-pod-name', 3]].forEach(function(p){
        document.querySelectorAll(p[0]).forEach(function(card){
          var nm = card.querySelector(p[1]);
          if(nm && nm.textContent.trim() === name){ podRank = p[2]; }
        });
      });
      if(podRank === 1){ return { text: '🎉🏆 優勝おめでとうございます 🏆🎉', urgency: 3 }; }
      if(podRank >= 2){ return { text: '🎊🏅 入賞おめでとうございます 🏅🎊', urgency: 4 }; }
    }

    /* 大会が結果確定済みなら「次のレースまで」カウントダウンは出さない（次のレースは存在しない）。
       表彰台（優勝/入賞）の祝福メッセージは上で先に返しているため、確定後も維持される。 */
    if(window.__M4_FINALIZED__) return null;

    /* ヒート（トーナメント）予選 */
    if(isHeatQual){
      var _htConts = document.querySelectorAll('[id^="viewer-ht-bracket-"]');
      var found = null;
      _htConts.forEach(function(cont){
        if(found) return;
        var rs = cont.querySelectorAll('.br-round');
        if(!rs.length) return;
        var mR = -1, mG = -1;
        rs.forEach(function(rnd, ri){
          rnd.querySelectorAll('.br-group').forEach(function(grp, gi){
            grp.querySelectorAll('.br-slot-name').forEach(function(el){
              if(el.textContent.trim() === name){ mR = ri; mG = gi; }
            });
          });
        });
        if(mR < 0) return;
        var mGrp = rs[mR].querySelectorAll('.br-group')[mG];
        if(mGrp && mGrp.classList.contains('has-winner')) return;   /* 出番終了 */
        var before = 0;
        rs.forEach(function(rnd, ri){
          rnd.querySelectorAll('.br-group').forEach(function(grp, gi){
            if(ri > mR) return;
            if(ri === mR && gi >= mG) return;
            if(grp.classList.contains('has-winner')) return;
            before++;
          });
        });
        rs.forEach(function(rnd){
          rnd.querySelectorAll('.br-slot-name').forEach(function(el){
            if(el.textContent.trim() === name){
              el.style.setProperty('background', 'rgb(230,126,34)', 'important');
              el.style.setProperty('color', '#ffffff', 'important');
              el.style.fontWeight = 'bold';
              var slot = el.closest('.br-slot') || el.parentElement;
              if(slot){
                slot.style.setProperty('background', 'rgb(230,126,34)', 'important');
                slot.style.setProperty('box-shadow', 'inset 0 0 0 2px rgb(160,80,15)', 'important');
              }
            }
          });
        });
        found = mkCountResult(name, before);   /* 数字はアクティブ起点の巡回順で上書き（無→DOM順） */
      });
      if(found) return found;
    }

    /* 決勝トーナメント（本戦。ヒート予選ページでは数えない） */
    if(!isHeatQual){
      var rounds = document.querySelectorAll('.br-round');
      if(rounds.length > 0){
        var myRound = -1, myGroup = -1;
        rounds.forEach(function(rnd, ri){
          rnd.querySelectorAll('.br-group').forEach(function(grp, gi){
            grp.querySelectorAll('.br-slot-name').forEach(function(el){
              if(el.textContent.trim() === name){ myRound = ri; myGroup = gi; }
            });
          });
        });
        if(myRound >= 0){
          var myGrpEl = rounds[myRound].querySelectorAll('.br-group')[myGroup];
          var eliminated = false;
          if(myGrpEl && myGrpEl.classList.contains('has-winner')){
            var w = (myGrpEl.dataset && myGrpEl.dataset.winnerName) ? myGrpEl.dataset.winnerName.trim() : '';
            if(w && w !== name){ eliminated = true; }
          }
          function isExcludedRound(rnd){
            var lb = rnd.querySelector('.br-round-label');
            var t = lb ? lb.textContent.trim() : '';
            if(t.indexOf('敗者復活') >= 0) return true;
            if(t.indexOf('裏') >= 0) return true;
            return false;
          }
          if(!eliminated && !isExcludedRound(rounds[myRound])){
            var before = 0;
            rounds.forEach(function(rnd, ri){
              if(isExcludedRound(rnd)) return;
              rnd.querySelectorAll('.br-group').forEach(function(grp, gi){
                if(ri > myRound) return;
                if(ri === myRound && gi >= myGroup) return;
                if(grp.classList.contains('has-winner')) return;
                before++;
              });
            });
            rounds.forEach(function(rnd){
              rnd.querySelectorAll('.br-slot-name').forEach(function(el){
                if(el.textContent.trim() === name){
                  el.style.setProperty('background', 'rgb(230,126,34)', 'important');
                  el.style.setProperty('color', '#ffffff', 'important');
                  el.style.fontWeight = 'bold';
                  var slot = el.closest('.br-slot') || el.parentElement;
                  if(slot){
                    slot.style.setProperty('background', 'rgb(230,126,34)', 'important');
                    slot.style.setProperty('box-shadow', 'inset 0 0 0 2px rgb(160,80,15)', 'important');
                  }
                }
              });
            });
            return mkCountResult(name, before);   /* 数字はアクティブ起点の巡回順で上書き（無→DOM順） */
          }
        }
      }
    }

    /* 予選（並び順など）の racer-cell テーブル */
    /* セル内には順位アイコン＋名前＋タイムが入るため、名前だけ（.rr-name span）で照合する。
       .rr-name が無い簡易セルはセル全体テキストにフォールバック。 */
    function rcName(cell){
      var n = cell.querySelector('.rr-name');
      return (n ? n.textContent : cell.textContent).trim();
    }
    var racerCells = document.querySelectorAll('.racer-cell');
    if(racerCells.length > 0){
      /* セルに結果（○×マーク / CO・順位バッジ）が入っていれば、そのレーサーは走行済み。
         none_roundrobin は heat.status=done が付かない場合があるため、結果マークでも判定する。 */
      function cellRun(cell){
        return !!(cell.querySelector('.rr-mark') || cell.querySelector('.rank-badge'));
      }
      /* 行が走行済みか（done クラス or 行内の全レーサーセルに結果）。
         区切り行など racer-cell を持たない行は対象外（走行済み扱い・カウントしない）。 */
      function rowRun(tr){
        if(tr.classList.contains('done')) return true;
        var cs = tr.querySelectorAll('.racer-cell');
        if(!cs.length) return true;
        return Array.prototype.every.call(cs, cellRun);
      }
      /* この名前が出走する行を document 順に収集（複数回出走に対応） */
      var myRows = [], _seen = [];
      racerCells.forEach(function(cell){
        if(rcName(cell) !== name) return;
        var tr = cell.closest('tr'); if(!tr) return;
        var idx = _seen.indexOf(tr);
        if(idx < 0){ _seen.push(tr); myRows.push({ tr: tr, cells: [cell] }); }
        else { myRows[idx].cells.push(cell); }
      });
      if(myRows.length > 0){
        /* 全出走に控えめハイライト（複数回出走でも全部わかる） */
        var SUB_BG = 'rgba(230,126,34,0.15)', SUB_BD = 'rgba(230,126,34,0.45)';
        myRows.forEach(function(r){
          r.cells.forEach(function(cell){
            var td = cell.closest('td') || cell;
            td.style.setProperty('background', SUB_BG, 'important');
            td.style.setProperty('box-shadow', 'inset 0 0 0 2px ' + SUB_BD, 'important');
          });
        });
        /* 次に走行する行＝未走行の最初の行。ここだけ現行の強いハイライト。 */
        var nextRow = null;
        for(var i = 0; i < myRows.length; i++){
          if(!rowRun(myRows[i].tr)){ nextRow = myRows[i]; break; }
        }
        if(nextRow){
          nextRow.cells.forEach(function(cell){
            var td = cell.closest('td') || cell;
            td.style.setProperty('background', 'rgb(230,126,34)', 'important');
            td.style.setProperty('box-shadow', 'inset 0 0 0 2px rgb(160,80,15)', 'important');
            cell.style.setProperty('color', '#ffffff', 'important');
            cell.style.fontWeight = 'bold';
          });
          /* 自分の前に残る未走行レース数（同じ tbody 内・区切り行等は除く） */
          var myTbody = nextRow.tr.closest('tbody');
          var rows = Array.from(myTbody.querySelectorAll('tr'));
          var myIdx = rows.indexOf(nextRow.tr);
          var before = 0;
          for(var ri = 0; ri < myIdx; ri++){
            if(rows[ri].querySelectorAll('.racer-cell').length && !rowRun(rows[ri])) before++;
          }
          return mkCountResult(name, before);   /* 数字はアクティブ起点の巡回順で上書き（無→DOM順） */
        }
        /* 未走行が無い＝全部走行済み → バナー無し（控えめハイライトは残す） */
        return null;
      }
    }

    return null;   /* このページでは出番なし・該当なし */
  }

  /* ---------- 「まもなく出走」通知（2組前で1回だけ・点滅＋バイブ／参加者html） ---------- */
  /* 既存の出走順計算（computeStatusForName）の結果から「自分の前に残る組数」を読み取り、
     2組前に入った瞬間だけ通知する。追加のポーリングは無く既存30秒サイクルに相乗り。
     点滅は3回で自動停止（無限アニメにしない）、バイブは1回のみ（iOS Safariは非対応＝点滅のみ）。 */
  function _beforeFromResult(res){
    if(!res) return null;
    if(res.urgency === 3 || res.urgency === 4) return null;   /* 優勝・入賞は対象外 */
    if(res.urgency === 0) return 0;                            /* あなたの番 */
    var digits = String(res.text).replace(/[^0-9]/g, '');     /* 「次のレースまでNレース」→ N */
    return digits ? parseInt(digits, 10) : null;
  }
  function _maybeSoonNotify(name, res){
    var before = _beforeFromResult(res);
    var key = 'm4_soon2_' + SLUG_KEY + '_' + name;
    var prevRaw = null;
    try { prevRaw = sessionStorage.getItem(key); } catch(e){}
    var prev = (prevRaw == null ? null : parseInt(prevRaw, 10));
    if(before == null){
      /* このページに出番が無い／終了 → 状態リセット（次に2組前へ入ったら再通知できる） */
      try { sessionStorage.removeItem(key); } catch(e){}
      return;
    }
    if(before === 2 && prev !== 2){ _fireSoonAlert(); }        /* 2組前へ入った瞬間だけ */
    try { sessionStorage.setItem(key, String(before)); } catch(e){}
  }
  function _fireSoonAlert(){
    if(document.getElementById('m4-soon-flash')) return;       /* 多重発火ガード（同一更新で1回） */
    try { if(navigator.vibrate) navigator.vibrate([200,100,200]); } catch(e){}   /* Androidのみ・1回 */
    var ov = document.createElement('div');
    ov.id = 'm4-soon-flash';
    ov.style.cssText = 'position:fixed;inset:0;z-index:99998;pointer-events:none;'
      + 'background:rgba(230,126,34,.85);opacity:0;transition:opacity .16s ease-in-out;'
      + 'display:flex;align-items:center;justify-content:center;';
    ov.innerHTML = '<div style="color:#fff;font-size:9vw;font-weight:bold;'
      + 'text-shadow:0 2px 12px rgba(0,0,0,.55);letter-spacing:2px">まもなく出走</div>';
    document.body.appendChild(ov);
    var shows = 0;
    (function step(){
      ov.style.opacity = '1';
      setTimeout(function(){
        ov.style.opacity = '0';
        shows++;
        if(shows >= 3){   /* 3回光ったら自動で消す（有限＝電池を食わない） */
          setTimeout(function(){ if(ov.parentNode) ov.parentNode.removeChild(ov); }, 220);
          return;
        }
        setTimeout(step, 190);
      }, 230);
    })();
  }

  /* ---------- 出走順バナー（選択レーサーごとに1行） ---------- */
  function renderPositionBanner(selectedList){
    var old = document.getElementById('m4-position-banner');
    if(old) old.remove();

    /* 直前のハイライトを全リセット */
    document.querySelectorAll('.br-slot-name').forEach(function(el){
      el.style.removeProperty('background'); el.style.removeProperty('color');
      el.style.fontWeight = '';
    });
    document.querySelectorAll('.br-slot').forEach(function(s){
      s.style.removeProperty('background'); s.style.removeProperty('box-shadow');
    });
    document.querySelectorAll('.racer-cell').forEach(function(c){
      var td = c.closest('td');
      if(td){ td.style.removeProperty('background'); td.style.removeProperty('box-shadow'); }
      c.style.removeProperty('background'); c.style.removeProperty('color');
      c.style.removeProperty('box-shadow'); c.style.fontWeight = '';
    });

    var _slotR = document.getElementById('m4-picker-slot');
    var _navR = document.querySelector('.v-nav');
    var _myBar = document.getElementById('m4-my-banner');
    var headerH = _slotR
      ? (_navR ? Math.round(_navR.getBoundingClientRect().height) : 44)
      : (_myBar ? Math.round(_myBar.getBoundingClientRect().height) : 44);

    if(!selectedList || selectedList.length === 0){
      document.body.style.paddingTop = _slotR ? '' : headerH + 'px';
      return;
    }

    var isHeatQual = document.querySelectorAll('[id^="viewer-ht-bracket-"]').length > 0;
    var lines = [];
    selectedList.forEach(function(r){
      var result = computeStatusForName(r.name, isHeatQual);
      if(result){ lines.push({ name: r.name, text: result.text, urgency: result.urgency }); }
      _maybeSoonNotify(r.name, result);   /* 「まもなく出走」＝2組前で1回だけ点滅＋バイブ */
    });

    if(lines.length === 0){
      document.body.style.paddingTop = _slotR ? '' : headerH + 'px';
      return;
    }

    var b = document.createElement('div');
    b.id = 'm4-position-banner';
    b.style.cssText = 'position:fixed;left:0;width:100vw;top:' + headerH + 'px;z-index:8999;'
      + 'padding:2px 10px;box-sizing:border-box;box-shadow:0 2px 6px rgba(0,0,0,.35);'
      + 'color:#fff;font-size:13px;text-align:center;'
      + 'transform:translateZ(0);-webkit-transform:translateZ(0);';
    b.innerHTML = lines.map(function(l){
      return '<div style="background:' + urgencyColor(l.urgency) + ';padding:6px 10px;'
        + 'border-radius:4px;margin:1px 0;font-weight:bold;">'
        + escHtml(l.name) + '：' + escHtml(l.text) + '</div>';
    }).join('');
    document.body.appendChild(b);

    var ownH = Math.round(b.getBoundingClientRect().height) || 36;
    document.body.style.paddingTop = (headerH + ownH) + 'px';
  }

  /* ---------- 全体適用 ---------- */
  function applyAll(){
    var list = getMyRacers();
    var names = list.map(function(r){ return r.name; });
    renderBanner(list);
    applyEntryHighlight(names);
    renderPositionBanner(list);
  }

  /* ---------- entry-card タップで選択トグル ---------- */
  function bindEntryCards(){
    document.querySelectorAll('.entry-card').forEach(function(card){
      // タイム詳細モーダルを開くカード（決勝進出レーサー）は、カードタップで
      // マイレーサー選択（ハイライト）しない。ハイライトは上部のレーサー選択のみ。
      if(card.classList.contains('rs-clickable')) return;
      card.style.cursor = 'pointer';
      card.addEventListener('click', function(){
        var n = card.querySelector('.entry-name');
        if(!n) return;
        var name = n.textContent.trim();
        var y = card.querySelector('.entry-yomi');
        toggleRacer(name, y ? y.textContent.trim() : '');
        applyAll();
      });
    });
  }

  /* ---------- グローバル公開（✕ボタン：全選択解除） ---------- */
  window.m4ClearMyRacer = function(){
    clearMyRacers();
    document.querySelectorAll('.entry-card').forEach(function(card){
      card.style.removeProperty('border');
      card.style.removeProperty('background');
      card.style.removeProperty('color');
      card.style.opacity = '';
      card.style.boxShadow = '';
      var n = card.querySelector('.entry-name');
      if(n){ n.style.removeProperty('background'); n.style.removeProperty('color'); n.style.fontWeight = ''; }
    });
    document.querySelectorAll('.br-slot-name').forEach(function(el){
      el.style.removeProperty('background');
      el.style.removeProperty('color');
      el.style.fontWeight = '';
    });
    document.querySelectorAll('.br-slot').forEach(function(s){
      s.style.removeProperty('background');
      s.style.removeProperty('box-shadow');
    });
    document.querySelectorAll('.racer-cell').forEach(function(c){
      var td = c.closest('td');
      if(td){ td.style.removeProperty('background'); td.style.removeProperty('box-shadow'); }
      c.style.removeProperty('background');
      c.style.removeProperty('color');
      c.style.removeProperty('box-shadow');
      c.style.fontWeight = '';
    });
    var pb = document.getElementById('m4-position-banner');
    if(pb) pb.remove();
    document.body.style.paddingTop = '';
    var panel = document.getElementById('m4-racer-panel');
    if(panel) panel.style.display = 'none';
    renderBanner([]);
  };

  /* ---------- 初期化（部分更新後の再適用にも使う） ---------- */
  function _m4Init(){
    bindEntryCards();
    applyAll();
  }
  window._m4Reapply = function(){ try { _m4Init(); } catch(e){} };
  window.addEventListener('load', function(){
    setTimeout(_m4Init, 600);
    pollRaceOrder();                      /* アクティブ起点の巡回順を取得 */
    setInterval(pollRaceOrder, 10000);    /* 既存の更新サイクルと同じ10秒間隔 */
  });
})();
</script>"""
    my_racer_script = my_racer_script.replace('__SLUGKEY__', _slug_key)
    my_racer_script = my_racer_script.replace('__RACEORDERURL__', _raceorder_url)

    # ▼ 追加：強制リロードボタン（参加者向けHTML用・body直下に生成＝再描画で消えない）
    reload_btn_script = """<script>
(function(){
  if(document.getElementById('m4-reload-btn')) return;
  var b=document.createElement('button');
  b.id='m4-reload-btn'; b.type='button'; b.title='再読み込み';
  b.setAttribute('aria-label','再読み込み'); b.textContent='\u21bb';
  b.style.cssText='position:fixed;top:58px;right:12px;z-index:99999;width:44px;height:44px;'
    +'border-radius:50%;border:none;cursor:pointer;padding:0;background:#f39c12;color:#fff;'
    +'opacity:.62;font-size:24px;line-height:44px;text-align:center;'
    +'box-shadow:0 2px 6px rgba(0,0,0,.3);-webkit-tap-highlight-color:transparent;';
  b.onclick=function(){try{var u=new URL(location.href);u.searchParams.set('_',Date.now());location.replace(u.toString());}catch(e){location.reload();}};
  document.body.appendChild(b);
})();
</script>"""

    # ▼ 追加：画面スリープ抑止（Wake Lock）。観覧画面を開いている間は画面を消えさせない。
    #   非対応端末・取得失敗は黙って無視（従来挙動を壊さない）。
    #   他アプリから戻る等で解除されたら visibilitychange で自動再取得する。
    # 画面スリープ抑止（Wake Lock）。観覧画面を開いている間は画面を消えさせない。
    #   iOS Safari対策：ページ表示時の自動取得は NotAllowedError で拒否されるため、
    #   最初のユーザー操作（タップ/スクロール/キー）を起点に取得する。
    #   ・解放後はタップで再取得 ・一度取得済みなら他アプリから戻った際に自動再取得
    #   ・非対応端末／取得失敗は黙って無視（従来挙動を壊さない）
    wakelock_script = """<script>
(function(){
  if(!('wakeLock' in navigator)) return;   /* 非対応端末は何もしない */
  var wakeLock=null;
  var acquiredOnce=false;

  function requestWakeLock(){
    if(document.visibilityState!=='visible' || wakeLock!==null) return;
    /* ユーザー操作ハンドラ内から同期的に呼ぶこと（iOSの起動条件） */
    navigator.wakeLock.request('screen').then(function(wl){
      wakeLock=wl; acquiredOnce=true;
      wakeLock.addEventListener('release', function(){ wakeLock=null; });
    }).catch(function(){ wakeLock=null; });   /* 取得失敗は黙って無視 */
  }

  /* 最初の操作（および解放後の再操作）で取得する */
  ['click','touchend','keydown'].forEach(function(ev){
    document.addEventListener(ev, function(){ requestWakeLock(); }, {passive:true});
  });

  /* 一度取得できていれば、他アプリから戻ったときに自動で取り直す */
  document.addEventListener('visibilitychange', function(){
    if(document.visibilityState==='visible' && wakeLock===null && acquiredOnce){ requestWakeLock(); }
  });
})();
</script>"""

    info_bar_script = """<script>
(function(){
  var el = document.getElementById('m4-info-data');
  var DATA = {};
  if(el){ try{ DATA = JSON.parse(el.textContent || '{}'); }catch(e){ DATA = {}; } }
  function esc(s){ return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
  window.m4ToggleZoom = function(img){
    if(img.getAttribute('data-z') === '1'){
      img.style.maxWidth='100%'; img.style.width=''; img.style.cursor='zoom-in'; img.setAttribute('data-z','0');
    } else {
      img.style.maxWidth='none'; img.style.width='auto'; img.style.cursor='zoom-out'; img.setAttribute('data-z','1');
    }
  };
  function slugPrefix(){
    var segs = location.pathname.split('/').filter(function(s){ return s; });
    var reserved = {admin:1, view:1, static:1, health:1, logo:1, api:1, enter:1, entry:1};
    if(segs.length && !reserved[segs[0]]){ return '/' + segs[0]; }
    return '';
  }
  var PREFIX = slugPrefix();
  function assetUrl(u){ return (u.charAt(0) === '/') ? (PREFIX + u) : u; }
  window.m4OpenInfo = function(kind){
    if(kind === 'm4laps'){
      // ⚡LAPS：非表示divの M4LAPS ベスト表をそのままモーダルに表示する。
      var src = document.getElementById('m4-laps-modal-content');
      var tt = document.getElementById('m4-info-title'); if(tt){ tt.textContent = '⚡ M4LAPS'; }
      var bb = document.getElementById('m4-info-body');
      if(bb){ bb.innerHTML = src ? src.innerHTML : '<div style="color:#95a5a6">（内容がありません）</div>'; }
      var ovv = document.getElementById('m4-info-overlay'); if(ovv){ ovv.style.display = 'block'; }
      window.__m4ModalOpen = true;
      return;
    }
    var d = DATA[kind]; if(!d) return;
    var t = document.getElementById('m4-info-title'); if(t){ t.textContent = d.title; }
    var html = '';
    if(d.text){ html += '<div style="white-space:pre-wrap;color:#ecf0f1;font-size:15px;line-height:1.7;margin-bottom:16px">'+esc(d.text)+'</div>'; }
    var items = d.items || [];
    for(var i=0;i<items.length;i++){
      html += '<div style="margin:0 0 16px">';
      html += '<div style="overflow:auto;-webkit-overflow-scrolling:touch;border-radius:8px;background:#000"><img src="'+assetUrl(items[i].u)+'" onclick="m4ToggleZoom(this)" style="max-width:100%;border-radius:8px;display:block;cursor:zoom-in;touch-action:pinch-zoom" data-z="0"></div>';
      html += '<div style="font-size:11px;color:#7f8c8d;margin-top:4px">タップで拡大／スワイプで移動</div>';
      if(items[i].n){ html += '<div style="color:#bdc3c7;font-size:12px;margin-top:2px">'+esc(items[i].n)+'</div>'; }
      html += '</div>';
    }
    if(!html){ html = '<div style="color:#95a5a6">（内容がありません）</div>'; }
    var b = document.getElementById('m4-info-body'); if(b){ b.innerHTML = html; }
    var ov = document.getElementById('m4-info-overlay'); if(ov){ ov.style.display = 'block'; }
    window.__m4ModalOpen = true;
  };
  window.m4CloseInfo = function(){
    var ov = document.getElementById('m4-info-overlay'); if(ov){ ov.style.display = 'none'; }
    window.__m4ModalOpen = false;
  };
  var bar = document.getElementById('m4-info-bar');
  if(bar){
    var barH = Math.round(bar.getBoundingClientRect().height);
    document.body.style.paddingBottom = (barH + 8) + 'px';
    // 「↑ 上へ」「🏆 過去成績」ボタンをタイスケ帯の上に必ず出す（帯の裏に隠れないよう持ち上げる）
    var _lift = (barH + 8) + 'px';
    var _tb = document.getElementById('m4-top-btn'); if(_tb){ _tb.style.bottom = _lift; }
    var _hb = document.getElementById('m4-history-btn'); if(_hb){ _hb.style.bottom = _lift; }
    var _hm = document.getElementById('m4-history-menu'); if(_hm){ _hm.style.bottom = 'calc(' + _lift + ' + 46px)'; }
  }
})();
</script>"""

    # お試し（お知らせ帯）テロップ：/api/telop を10秒ごとに確認して帯を出し入れする。
    # 参加者htmlは <script> が全除去されるため、ここで専用ポーラーを注入する。
    telop_script = ("""<script>
(function(){
  var URL = "__TELOPURL__";
  var TID = "__TID__";
  /* アクセス統計用の端末ID（ブラウザごとに1つ。ユニーク視聴者の集計に使う） */
  var CID = (function(){
    try {
      var k = 'm4_cid';
      var v = localStorage.getItem(k);
      if(!v){ v = Date.now().toString(36) + Math.random().toString(36).slice(2, 10); localStorage.setItem(k, v); }
      return v;
    } catch(e){ return ''; }
  })();
  function apply(d){
    var bar = document.getElementById('m4-telop');
    if(!bar) return;
    var t = (d && d.active && d.text) ? d.text : '';
    if(t){
      var span = document.getElementById('m4-telop-text');
      if(span) span.textContent = t;
      bar.style.display = 'flex';
    } else {
      bar.style.display = 'none';
    }
  }
  function poll(){
    /* 既存のテロップ確認に cid/tid を相乗り（新規リクエストは増やさない＝アクセス統計の心拍） */
    var u = URL + (URL.indexOf('?') >= 0 ? '&' : '?') + 'cid=' + encodeURIComponent(CID) + '&tid=' + TID;
    fetch(u, {cache:'no-store'})
      .then(function(r){ return r.json(); })
      .then(apply).catch(function(){});
  }
  /* SSE(即時push)からも呼べるように公開（update/telop受信時に即実行） */
  window.__m4TelopPoll = poll;
  poll();
  setInterval(poll, 10000);
})();
</script>""").replace("__TELOPURL__", _telop_url).replace("__TID__", _tid)

    # 待機画面の日時時計：参加者htmlは<script>が除去されるため専用に注入（端末のローカル時刻）。
    # 時計要素が無いページ（レース進行中など）では何もしない。
    clock_script = """<script>
(function(){
  var dateEl = document.getElementById('v-clock-date');
  var timeEl = document.getElementById('v-clock-time');
  if(!dateEl && !timeEl) return;
  var WD = ['日','月','火','水','木','金','土'];
  function z(n){ return (n < 10 ? '0' : '') + n; }
  function tick(){
    var d = new Date();
    if(dateEl){ dateEl.textContent = d.getFullYear()+'年'+z(d.getMonth()+1)+'月'+z(d.getDate())+'日（'+WD[d.getDay()]+'）'; }
    if(timeEl){ timeEl.textContent = z(d.getHours())+'：'+z(d.getMinutes()); }
  }
  tick();
  setInterval(tick, 1000);
})();
</script>"""

    # 旧版JSで開きっぱなしのタブを一度だけフルリロードさせる不可視マーカー。
    # 旧版の更新検知は「構造世代印」（.schedule-table の個数を含む）が変わると
    # location.reload() する。非表示の空 .schedule-table を恒久的に置くことで、
    # 旧版基準と必ず世代が食い違い、旧タブは次回ポーリングで新HTML（ゲートJS入り）
    # に置き換わる。新版クライアントには常に同じ形で見えるため無害（表示なし・
    # 行数0なので世代印は以後安定する）。
    _migrate_marker = '<div style="display:none" aria-hidden="true"><table class="schedule-table"></table></div>'
    patched = patched.replace('</body>', _migrate_marker + expiry_script + my_racer_script + redraw_script + reload_btn_script + wakelock_script + info_bar_script + telop_script + clock_script + racer_stats_js + '</body>', 1)

    # スラッグ店舗: 公開HTMLは内部レンダリング（StoreResolver の応答書き換えを通らない）
    # で生成されるため、本文に残るクォート直後の絶対パス（例: /api/race-asset の画像、
    # 保持スクリプト内の fetch 先）がスラッグ無しのまま＝既定店舗向けになってしまう。
    # 通常応答と同一の規則で "/{slug}" を前置し、ライブ画面と公開HTMLの動作を一致させる。
    # 既定店舗（slug=""）は無加工＝従来どおり。既に "/{slug}/..." のURLは
    # クォート直後が "/{slug}" のため二重前置されない（resolver と同じ性質）。
    if slug:
        patched = _re.sub(
            r"([\"'`])(/(?:admin|view|static|logo|health|api|enter)\b)",
            lambda m: f"{m.group(1)}/{slug}{m.group(2)}",
            patched,
        )
    return patched


async def _render_page(view_url: str, store=None) -> str | None:
    """
    viewer の各ルーター関数を直接呼び出してHTMLを生成する。
    戻り値: HTML文字列 or None（対応するページがない場合）
    """
    from app.main import app

    try:
        import httpx
        from app.config import (
            IS_CLOUD as _IS_CLOUD, ADMIN_TOKEN as _ADMIN_TOKEN,
            ADMIN_COOKIE as _ADMIN_COOKIE, admin_cookie_name as _acn,
        )
        _headers = {}
        if _IS_CLOUD and store is not None:
            # 店舗別Cookie＋内部レンダリングヘッダ（resolver が店舗を確定）
            _cookies = {_acn(store.id): store.admin_token} if store.admin_token else {}
            _headers["x-internal-store-id"] = str(store.id)
            # INTERNAL_RENDER_SECRET 設定時は resolver が署名一致を要求する。
            # 未送信だとバイパス不成立→既定店舗として解決され、スラッグ店舗の
            # 配信HTMLが誤った内容（別店舗DB／ログイン画面）で書き出される。
            import os as _os_sec
            _sec = _os_sec.environ.get("INTERNAL_RENDER_SECRET", "")
            if _sec:
                _headers["x-internal-render-secret"] = _sec
        else:
            _cookies = {_ADMIN_COOKIE: _ADMIN_TOKEN} if (_IS_CLOUD and _ADMIN_TOKEN) else {}
        async with httpx.AsyncClient(app=app, base_url="http://localhost", follow_redirects=True, cookies=_cookies, headers=_headers) as client:
            # 参加者向けhtml生成であることをテンプレートへ伝えるため _public=1 を付与
            _sep = "&" if ("?" in view_url) else "?"
            _get_url = view_url + _sep + "_public=1"
            resp = await client.get(_get_url)
            print(f"[public_html] render status: {_get_url} -> {resp.status_code} (final url: {resp.url})", flush=True)
            if resp.status_code == 200:
                return resp.text
            return None
    except Exception as e:
        print(f"[public_html] render error: {e}", flush=True)
        return None


def _find_key_file() -> str | None:
    """
    サービスアカウントキーファイルを探す。
    優先順位:
      1. 環境変数 GOOGLE_APPLICATION_CREDENTIALS
      2. アプリ直下の miniyonku-gcs-key.json
    """
    import os
    # 環境変数が設定されていればそちらを優先（Cloud Run等）
    env = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "")
    if env and os.path.exists(env):
        return env
    # アプリ直下を探す（ローカルPC運用）
    base = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    key_path = os.path.join(base, "miniyonku-gcs-key.json")
    if os.path.exists(key_path):
        return key_path
    return None


async def _inject_bracket_html(html: str, view_url: str, store=None) -> str:
    """
    静的HTML内の動的fetchで埋まるコンテナに、実際のbracket/htmlを埋め込む。
    対象:
      - #viewer-ht-bracket-{hno}  (qualifying/heat-tournament)
      - #bracket-html-container    (bracket)
    """
    import re
    from app.main import app
    import httpx
    from app.config import (
        IS_CLOUD as _IS_CLOUD2, ADMIN_TOKEN as _ADMIN_TOKEN2,
        ADMIN_COOKIE as _ADMIN_COOKIE2, admin_cookie_name as _acn2,
    )
    _headers2 = {}
    if _IS_CLOUD2 and store is not None:
        _cookies2 = {_acn2(store.id): store.admin_token} if store.admin_token else {}
        _headers2["x-internal-store-id"] = str(store.id)
        # INTERNAL_RENDER_SECRET 設定時は resolver が署名一致を要求する（_render_page と同様）。
        import os as _os_sec2
        _sec2 = _os_sec2.environ.get("INTERNAL_RENDER_SECRET", "")
        if _sec2:
            _headers2["x-internal-render-secret"] = _sec2
    else:
        _cookies2 = {_ADMIN_COOKIE2: _ADMIN_TOKEN2} if (_IS_CLOUD2 and _ADMIN_TOKEN2) else {}

    async with httpx.AsyncClient(app=app, base_url="http://localhost", follow_redirects=True, cookies=_cookies2, headers=_headers2) as client:

        # ① qualifying heat-tournament ブラケット（section単位で注入）
        # 差込先 id は viewer-ht-bracket-{hno}-{section_no}（section_no=0 はヒート決勝）。
        # view 側 JS（loadHtBracketSection）と同一のエンドポイント・パラメータで取得する。
        m = re.search(r"/view/tournament/(\d+)/qualifying", view_url)
        if m:
            tid = m.group(1)
            _PH = '<div style="color:#7f8c8d;font-size:12px;padding:8px">読み込み中...</div>'
            # HTMLから (hno, section_no) を収集
            ht_pairs = re.findall(r'id="viewer-ht-bracket-(\d+)-(\d+)"', html)
            for hno, sec in ht_pairs:
                _url = (
                    f"/admin/tournaments/{tid}/qualifying/heat-tournament/{hno}"
                    f"/bracket/html?compact=2&section_no={sec}"
                )
                if int(sec) == 0:
                    _url += "&heat_final=1"
                resp = await client.get(_url)
                if resp.status_code != 200:
                    continue
                bracket_html = resp.text
                # 該当コンテナ（id）以降の最初の「読み込み中」プレースホルダだけを差し替える
                marker = f'id="viewer-ht-bracket-{hno}-{sec}"'
                pos = html.find(marker)
                if pos == -1:
                    continue
                ph_pos = html.find(_PH, pos)
                if ph_pos == -1:
                    continue
                html = html[:ph_pos] + bracket_html + html[ph_pos + len(_PH):]

            # heat-roundrobin ブラケット
            hr_pattern = re.compile(r'id="viewer-hr-bracket-(\d+)"')
            hr_nos = hr_pattern.findall(html)
            for hno in hr_nos:
                resp = await client.get(
                    f"/admin/tournaments/{tid}/qualifying/heat-roundrobin/{hno}/bracket/html"
                )
                if resp.status_code == 200:
                    bracket_html = resp.text
                    old_container = re.search(
                        f'id="viewer-hr-bracket-{hno}"' + r'[^>]*>.*?</div>',
                        html, flags=re.DOTALL
                    )
                    if old_container:
                        tag_open = old_container.group(0).split('>')[0] + '>'
                        html = html[:old_container.start()] + tag_open + bracket_html + '</div>' + html[old_container.end():]

        # ② bracket (決勝トーナメント)
        m = re.search(r"/view/tournament/(\d+)/bracket", view_url)
        if m:
            tid = m.group(1)
            if 'id="bracket-html-container"' in html:
                resp = await client.get(f"/admin/tournaments/{tid}/bracket/html")
                if resp.status_code == 200:
                    bracket_html = resp.text
                    if bracket_html.strip() and '開始されていません' not in bracket_html:
                        html = html.replace(
                            '<div id="bracket-html-container"></div>',
                            f'<div id="bracket-html-container">{bracket_html}</div>'
                        )
                        # bracket注入成功時はno-bracketを非表示に戻す
                        html = html.replace(
                            '<div id="no-bracket" style="display:block;',
                            '<div id="no-bracket" style="display:none;',
                        )

    _is_qual = bool(re.search(r"/view/tournament/\d+/qualifying", view_url))

    # 決勝トーナメント表(.br-wrap)が万一二重に出た場合は、先頭＝上の1つだけ残す。
    # JS ガード(_m4DedupBracket)は公開HTMLのJS除去や部分更新のタイミングで効かない
    # ことがあるため、サーバー側でも「上だけ」を保証する。
    # ※予選ヒートトーナメント/ヒート決勝はヒート・セクションごとに複数の .br-wrap が
    #   正規に並ぶ。ここで先頭だけ残すと正規のブラケットまで消えてしまうため、予選では
    #   一括間引きを行わず、後述の「👥エントリー以降を除去」で誤混入分だけを消す。
    if not _is_qual:
        html = _keep_first_br_wrap(html)

    # ⚡ M4LAPS ベスト表・🏆 決勝進出レーサー節も、決勝表(.br-wrap)と同様に
    # 部分更新(applyPartial)のタイミングで二重化することがあるため、先頭の1つだけ残す。
    # bracket.html 側で付与した安定 id をマーカーにブロック単位で除去する。
    html = _keep_first_div_block(html, '<div id="m4-laps-sec"')
    html = _keep_first_div_block(html, '<div id="m4-finalists-sec"')

    # 予選ページ限定：👥エントリー一覧より後ろに出た表示をすべて除去する（＝エントリーの下は何も出さない）。
    #   予選ページの正規レイアウトでは、トーナメント表(.br-wrap)・⚡M4LAPSベスト表・🏆決勝進出節は
    #   必ずエントリーより上にある。エントリー以降にこれらが残るのは注入/重複の誤混入なので安全に消せる。
    #   ※決勝ページ(/bracket)はエントリーの後にブラケットが正規に来るため、URLで予選だけに限定する。
    if _is_qual:
        html = _strip_blocks_after(html, "👥 エントリー", [
            '<div class="br-wrap">',       # 決勝/ヒートのトーナメント表
            '<div class="br-wrap"',        # 属性付きの br-wrap（前方一致）
            '<div id="m4-laps-sec"',       # ⚡ M4LAPS ベスト表
            '<div id="m4-finalists-sec"',  # 🏆 決勝進出レーサー節
        ])

    return html


_SCRIPT_STYLE_RE = re.compile(r'<(script|style)\b[^>]*>.*?</\1>', re.DOTALL | re.IGNORECASE)


def _mask_script_style(html: str) -> str:
    """<script>/<style> ブロックを同じ長さの空白へ置換する（インデックスは不変）。
    ブラケットHTMLは内部に <script>/<style> を含み、その中の文字列に <div/</div> が
    現れると div の対応数えを誤るため、数える前にマスクして無害化する。"""
    return _SCRIPT_STYLE_RE.sub(lambda m: " " * len(m.group(0)), html)


def _div_block_end(masked: str, open_pos: int):
    """masked（script/style マスク済み）で open_pos の <div> に対応する </div> の
    直後インデックスを返す。対応が取れなければ None。"""
    depth = 0
    p = open_pos
    n = len(masked)
    while p < n:
        nd = masked.find('<div', p)
        nc = masked.find('</div>', p)
        if nc == -1:
            return None
        if nd != -1 and nd < nc:
            depth += 1
            p = nd + 4
        else:
            depth -= 1
            p = nc + 6
            if depth == 0:
                return p
    return None


def _keep_first_div_block(html: str, open_marker: str) -> str:
    """open_marker で始まる <div> ブロックが複数あれば、先頭(=文書順で最初=画面の上)
    だけ残して以降を除去する。ネストした <div> を数えてブロック単位で正しく取り除く
    （正規表現では閉じタグを誤認するため）。

    open_marker は開始タグの先頭一致文字列。
      例: '<div class="br-wrap">' / '<div id="m4-laps-sec"' / '<div id="m4-finalists-sec"'
    id マーカーは属性（class/style 等）が続くため、'>' を含めない前方一致で指定する。
    """
    first = html.find(open_marker)
    if first == -1:
        return html
    while True:
        second = html.find(open_marker, first + len(open_marker))
        if second == -1:
            break
        # second から始まる div ブロックの終端を <div>/</div> の対応で探す
        # （<script>/<style> 内の <div> は数えない）
        end = _div_block_end(_mask_script_style(html), second)
        if end is None:
            break
        html = html[:second] + html[end:]
    return html


def _keep_first_br_wrap(html: str) -> str:
    """後方互換ラッパー：決勝トーナメント表(.br-wrap)が複数あれば先頭だけ残す。"""
    return _keep_first_div_block(html, '<div class="br-wrap">')


def _strip_blocks_after(html: str, after_marker: str, block_markers: list) -> str:
    """after_marker（最後の出現位置）より後ろに現れる、block_markers のいずれかで始まる
    <div> ブロックを、すべてブロック単位で除去する。ネストした <div> を数えて終端を正しく
    判定する（_keep_first_div_block と同じ数え方）。

    用途：予選公開HTMLで『👥エントリー一覧より下に誤って出た表示（トーナメント表・M4LAPS
    ベスト表・決勝進出節）』を消す。正規レイアウトではこれらはエントリーより上にあるため、
    ここで消えるのは誤混入分だけ（エントリー節そのものは開始タグが marker より前なので消えない）。
    """
    base = html.rfind(after_marker)
    if base == -1:
        return html
    start = base + len(after_marker)
    while True:
        # start 以降で最も手前に現れる block_marker を探す
        best = None
        for mk in block_markers:
            p = html.find(mk, start)
            if p != -1 and (best is None or p < best):
                best = p
        if best is None:
            break
        # best から始まる div ブロックの終端（<script>/<style> 内の <div> は無視）
        end = _div_block_end(_mask_script_style(html), best)
        if end is None:
            break
        html = html[:best] + html[end:]
    return html


async def _upload_to_gcs(html: str, bucket: str) -> bool:
    """GCS の index.html に上書きアップロード"""
    try:
        from google.cloud import storage  # type: ignore
        from google.oauth2 import service_account  # type: ignore

        key_path = _find_key_file()
        if key_path:
            credentials = service_account.Credentials.from_service_account_file(
                key_path,
                scopes=["https://www.googleapis.com/auth/cloud-platform"],
            )
            client = storage.Client(credentials=credentials)
        else:
            # Cloud Run上はデフォルト認証（環境変数不要）
            client = storage.Client()

        b = client.bucket(bucket)
        blob = b.blob("index.html")
        blob.cache_control = "no-store, max-age=0"
        blob.upload_from_string(
            html.encode("utf-8"),
            content_type="text/html; charset=utf-8",
        )
        print(f"[public_html] uploaded to gs://{bucket}/index.html", flush=True)
        return True
    except Exception as e:
        print(f"[public_html] GCS upload error: {e}", flush=True)
        return False


# host_state を参照するためにviewerモジュールから取得（複数店舗化: 店舗別）
def _current_store():
    try:
        from app.store_context import current_store
        return current_store.get()
    except Exception:
        return None


def _get_host_state_url(store=None) -> str:
    try:
        from app.routers.viewer import _host_states
        sid = store.id if store is not None else 0
        st = _host_states.get(sid) or _host_states.get(0) or {}
        return st.get("url", "/view/")
    except Exception:
        return "/view/"


async def export_current_html(db=None) -> bool:
    """
    現在のhost_state URLに対応するページを生成して配信する。

    - クラウド版（IS_CLOUD）：PUBLIC_HTML_DIR/index.html へ書き出す（nginx が直接配信）。
      設定の public_html_enabled / bucket には依存しない（常に書き出す）。
    - オンプレ版：従来どおり、設定が有効な場合のみ GCS へアップロードする。

    設定が無効な場合（オンプレ）は何もせず True を返す。
    db引数は後方互換のため残しているが使用しない（内部で新規接続を開く）。
    """
    import aiosqlite
    from app.models.database import DB_PATH
    from app.config import IS_CLOUD, PUBLIC_HTML_DIR

    # 複数店舗化：現在の店舗（ContextVar）を解決。クラウドで未解決なら既定店舗。
    store = _current_store()
    if IS_CLOUD and store is None:
        try:
            from app import registry
            store = registry.get_default_store()
        except Exception:
            store = None

    db_path = store.db_path if store else DB_PATH
    out_dir = store.public_dir if store else PUBLIC_HTML_DIR
    slug = store.slug if store else ""

    async with aiosqlite.connect(db_path) as own_db:
        own_db.row_factory = aiosqlite.Row

        settings = await _get_settings(own_db)

        # オンプレ：設定が無効なら何もしない。クラウド：常に書き出す。
        if not IS_CLOUD and settings.get("public_html_enabled") != "1":
            return True

        if not IS_CLOUD:
            bucket = settings.get("public_html_gcs_bucket", "").strip()
            if not bucket:
                print("[public_html] bucket name not configured", flush=True)
                return False

        view_url = await _resolve_active_url(own_db, store)
        print(f"[public_html] target url: {view_url} (store={slug or 'default'})", flush=True)

        html = await _render_page(view_url, store)
        if not html:
            print(f"[public_html] render FAILED for: {view_url}", flush=True)
            return False

        print(f"[public_html] render OK ({len(html)} bytes), injecting bracket html...", flush=True)
        html = await _inject_bracket_html(html, view_url, store)
        # 結果確定済み判定（確定後は「次のレースまで」案内を抑止するためのフラグ注入用）
        _is_final = False
        try:
            import re as _re_fin
            _mfin = _re_fin.search(r"/view/tournament/(\d+)", view_url)
            if _mfin:
                from app.routers.tournaments import _is_result_finalized
                _is_final = await _is_result_finalized(int(_mfin.group(1)), own_db)
        except Exception:
            _is_final = False
        # 連動型ラップタイマー M4LAPS が有効な店舗だけラップタイム(TA)ボタンを表示。
        # 判定はこの店舗のDB(own_db)で行うので、slug有無・店舗ごとに独立。
        _ta_enabled = False
        try:
            if IS_CLOUD:
                async with own_db.execute(
                    "SELECT value FROM app_settings WHERE key='m4laps_licensed'"
                ) as _cur_ta:
                    _row_ta = await _cur_ta.fetchone()
                _ta_enabled = bool(_row_ta) and (_row_ta[0] == "1")
        except Exception:
            _ta_enabled = False
        html = _patch_html_for_static(html, slug, is_finalized=_is_final,
                                      ta_enabled=_ta_enabled)
        # ホーム画面アイコン（Webアプリ）: <head> へメタ注入 ＋ 静的 manifest 書き出し（クラウド版のみ）
        try:
            from app import pwa as _pwa
            if IS_CLOUD:
                _pwa_settings = _pwa.get_pwa_settings(db_path=db_path)
                if _pwa_settings.get("pwa_enabled") == "1":
                    _head = _pwa.render_pwa_head_html(_pwa_settings, slug)
                    if _head and "</head>" in html:
                        html = html.replace("</head>", _head + "</head>", 1)
                    _pwa.write_static_html_manifest(out_dir, _pwa_settings, slug)
        except Exception as _e:
            print(f"[public_html] pwa inject skipped: {_e}", flush=True)
        print(f"[public_html] patched ({len(html)} bytes), publishing...", flush=True)

        if IS_CLOUD:
            result = _write_local_html(html, out_dir, slug, store)
        else:
            bucket = settings.get("public_html_gcs_bucket", "").strip()
            result = await _upload_to_gcs(html, bucket)
        if result:
            print(f"[public_html] publish OK", flush=True)
        return result


CONTENT_FILENAME = "content.html"


def gated_content_path(store) -> str:
    """観覧内容本体の保存先。【nginx の公開ディレクトリの外】に置く。
    公開ディレクトリ内に置くと /content.html を直接取得できてしまうため、
    店舗DBと同じデータディレクトリに pub_content_<slug>.html として保存する。"""
    import os
    try:
        from app.models.database import DB_PATH
    except Exception:
        DB_PATH = ""
    db_path = (getattr(store, "db_path", "") if store is not None else "") or DB_PATH
    base_dir = os.path.dirname(os.path.abspath(db_path)) if db_path else ""
    slug = (getattr(store, "slug", "") if store is not None else "") or "default"
    return os.path.join(base_dir, f"pub_content_{slug}.html") if base_dir else ""


def _build_shell_html(full_html: str, slug: str) -> str:
    """nginx が静的配信する index.html（＝内容を持たない「中継専用」シェル）を生成する。

    方針:
      - 素の / では観覧内容を【絶対に表示しない】。固定URLに内容を出さないため、
        有効クッキーがあれば「その日だけの観覧URL（/enter/<当日の単語>）」へ中継し、
        無ければ失効ページへ送る。アドレスバーに毎日変わるURLを出すのが狙い。
      - 当日の秘密語はクッキー検証に通った端末にだけ /enter?api=entrypath が返す
        （無許可端末には渡さない）。
    <head> の manifest / アイコン / テーマ色は本体から引き継ぎ、PWA追加時の見え方を保つ。
    """
    import re as _re
    pfx = ("/" + slug) if slug else ""
    head_keep = ""
    for tag in _re.findall(r'<(?:link|meta)[^>]*>', full_html, flags=_re.IGNORECASE):
        tl = tag.lower()
        if ('rel="manifest"' in tl or "rel='manifest'" in tl
                or "apple-touch-icon" in tl or "apple-mobile-web-app" in tl
                or 'name="theme-color"' in tl or "name='theme-color'" in tl
                or 'rel="icon"' in tl or "rel='icon'" in tl):
            head_keep += tag
    m = _re.search(r'<title>(.*?)</title>', full_html, flags=_re.IGNORECASE | _re.DOTALL)
    title = m.group(1) if m else "観覧画面"
    return f"""<!doctype html><html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="referrer" content="no-referrer">
<meta http-equiv="Cache-Control" content="no-store">
<title>{title}</title>{head_keep}
<style>html,body{{margin:0;background:#141821;color:#cfd8e3;font-family:sans-serif}}
#m4-shell{{min-height:100vh;display:flex;align-items:center;justify-content:center;font-size:14px;opacity:.8}}</style>
</head><body><div id="m4-shell">読み込み中…</div>
<script>
(function(){{
  var ENTRYPATH = "{pfx}/enter?api=entrypath";  // 有効時のみ当日の観覧URLを返す
  var EXPIRED   = "{pfx}/enter?src=expired";     // 無効時はQR再スキャン案内へ
  function fail(){{ try {{ location.replace(EXPIRED); }} catch(e) {{}} }}
  fetch(ENTRYPATH, {{cache:'no-store', credentials:'same-origin'}}).then(function(r){{
    return r.ok ? r.json() : null;
  }}).then(function(j){{
    if(j && j.ok && j.path) {{ location.replace(j.path); }}  // 当日の観覧URLへ
    else {{ fail(); }}
  }}).catch(function(){{
    var el = document.getElementById('m4-shell');
    if(el) el.textContent = '通信できません。電波状況を確認して再読み込みしてください。';
  }});
}})();
</script><noscript>この画面の表示には JavaScript が必要です。</noscript></body></html>"""


def _write_local_html(html: str, out_dir: str, slug: str = "", store=None) -> bool:
    """クラウド版：参加者向けHTMLを書き出す。

    - gated_content_path(store) : 観覧内容の本体（公開ディレクトリ外。
                                  /api/pub-content がクッキー検証後に返す）
    - out_dir/index.html        : 内容を持たないシェル（nginx 直接配信。誰が取得しても無害）
    """
    import os
    if not out_dir:
        print("[public_html] PUBLIC_HTML_DIR が未設定です。", flush=True)
        return False
    gated = gated_content_path(store)
    if not gated:
        print("[public_html] 観覧内容の保存先を解決できません（DBパス未設定）。", flush=True)
        return False
    try:
        os.makedirs(out_dir, exist_ok=True)
        os.makedirs(os.path.dirname(gated), exist_ok=True)
        targets = ((gated, html), (os.path.join(out_dir, "index.html"), _build_shell_html(html, slug)))
        for dst, body in targets:
            # 一時ファイルへ書いてから rename（配信中の半端な読み取りを防ぐ）
            tmp = dst + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                f.write(body)
            os.replace(tmp, dst)
            print(f"[public_html] wrote {dst}", flush=True)
        # 旧版が公開ディレクトリに置いた content.html が残っていれば削除（漏洩防止）
        stale = os.path.join(out_dir, CONTENT_FILENAME)
        if os.path.isfile(stale):
            os.remove(stale)
        return True
    except Exception as e:
        print(f"[public_html] local write error: {e}", flush=True)
        return False


async def _resolve_active_url(db, store=None) -> str:
    """
    参加者向けHTMLの生成対象URLを host_state に完全に一致させる。

    host_state は admin の画面追従で更新される（viewer.host_sync）。
    - host_state がレース画面（/view/tournament/...）      → そのレース画面を生成
    - host_state が /view/（レース4画面以外を開いた/待機） → お待ちくださいを生成
    view 画面は host_state を直接見て描画するため、HTML もこれに揃えることで
    「view は待機中なのに HTML だけレース画面が残る」不一致を防ぐ。
    （以前は host_state が /view/ でも DB の進行中レースを拾ってレース画面を
      返していたため、admin が待機画面に切り替えても HTML が連動しなかった。）
    """
    hs_url = _get_host_state_url(store)
    if hs_url in ("/view/", "/view"):
        return "/view/"
    return hs_url