"""timing_devices / timing_layouts へのアクセス。

既存リポジトリ（racer_repository 等）と同じく、aiosqlite.Connection を受け取り
SQL を薄くラップする。ドメイン判断（バリデーション等）は持たない。
"""

import aiosqlite


class TimingDeviceRepository:
    """端末台帳（固定12台）へのアクセス。"""

    def __init__(self, db: aiosqlite.Connection):
        self.db = db

    async def list_all(self):
        async with self.db.execute(
            "SELECT node_id, kind, label, mac, note, sensor_width_mm FROM timing_devices "
            "ORDER BY node_id"
        ) as cur:
            return await cur.fetchall()

    async def list_by_kind(self, kind: str):
        async with self.db.execute(
            "SELECT node_id, kind, label, mac, note FROM timing_devices "
            "WHERE kind = ? ORDER BY node_id",
            (kind,),
        ) as cur:
            return await cur.fetchall()

    async def get(self, node_id: int):
        async with self.db.execute(
            "SELECT node_id, kind, label, mac, note, sensor_width_mm FROM timing_devices "
            "WHERE node_id = ?",
            (node_id,),
        ) as cur:
            return await cur.fetchone()

    async def update_meta(self, node_id: int, label: str, mac: str, note: str,
                          sensor_width_mm=None):
        """表示名・MAC・メモ・センサー幅の更新（node_id と kind は固定）。

        sensor_width_mm: ダブルセンサーの間隔(mm)。None なら未設定に戻す。
        """
        await self.db.execute(
            "UPDATE timing_devices SET label = ?, mac = ?, note = ?, sensor_width_mm = ? "
            "WHERE node_id = ?",
            (label, mac, note, sensor_width_mm, node_id),
        )
        await self.db.commit()


class TimingLayoutRepository:
    """コースレイアウト（地図）へのアクセス。"""

    def __init__(self, db: aiosqlite.Connection):
        self.db = db

    async def list_layouts(self):
        async with self.db.execute(
            "SELECT id, name, target_laps, created_at, updated_at "
            "FROM timing_layouts ORDER BY updated_at DESC, id DESC"
        ) as cur:
            return await cur.fetchall()

    async def get_layout(self, layout_id: int):
        async with self.db.execute(
            "SELECT id, name, target_laps, lap_length_m, created_at, updated_at "
            "FROM timing_layouts WHERE id = ?",
            (layout_id,),
        ) as cur:
            return await cur.fetchone()

    async def get_elements(self, layout_id: int):
        """通過順に並んだ要素列を返す。"""
        async with self.db.execute(
            "SELECT id, position, kind, node_id, beam_gap_mm "
            "FROM timing_layout_elements WHERE layout_id = ? ORDER BY position",
            (layout_id,),
        ) as cur:
            return await cur.fetchall()

    async def create_layout(self, name: str, target_laps: int) -> int:
        cur = await self.db.execute(
            "INSERT INTO timing_layouts (name, target_laps) VALUES (?, ?)",
            (name, target_laps),
        )
        await self.db.commit()
        return cur.lastrowid

    async def save_elements(self, layout_id: int, elements: list[dict]):
        """要素列を丸ごと置き換える（position 0..N-1 で入れ直す）。

        elements: [{"kind": "SG"|"SQ"|"LC", "node_id": int|None,
                    "beam_gap_mm": float|None}, ...]（通過順）
        beam_gap_mm は2本のビームの間隔(mm)。通過速度の算出に使う（省略可）。
        """
        await self.db.execute(
            "DELETE FROM timing_layout_elements WHERE layout_id = ?",
            (layout_id,),
        )
        for pos, el in enumerate(elements):
            await self.db.execute(
                "INSERT INTO timing_layout_elements "
                "(layout_id, position, kind, node_id, beam_gap_mm) "
                "VALUES (?, ?, ?, ?, ?)",
                (layout_id, pos, el["kind"], el.get("node_id"),
                 el.get("beam_gap_mm")),
            )
        await self.db.execute(
            "UPDATE timing_layouts SET updated_at = datetime('now','localtime') "
            "WHERE id = ?",
            (layout_id,),
        )
        await self.db.commit()

    # 「指定なし＝変更しない」と「明示的にNone＝クリア」を区別するための番兵
    _UNSET = object()

    async def update_meta(self, layout_id: int, name: str, target_laps: int,
                          lap_length_m=_UNSET):
        """レイアウトの基本情報を更新する。

        lap_length_m: 1周の距離(m)。ラップ平均速度の算出に使う。
          - 省略  … 変更しない
          - float … その値を設定
          - None  … 未設定に戻す（クリア）
        ⚠ None を「変更しない」と扱うと設定を解除できなくなるため、
           省略時の番兵(_UNSET)と明確に区別している。
        """
        if lap_length_m is self._UNSET:
            await self.db.execute(
                "UPDATE timing_layouts SET name = ?, target_laps = ?, "
                "updated_at = datetime('now','localtime') WHERE id = ?",
                (name, target_laps, layout_id),
            )
        else:
            await self.db.execute(
                "UPDATE timing_layouts SET name = ?, target_laps = ?, lap_length_m = ?, "
                "updated_at = datetime('now','localtime') WHERE id = ?",
                (name, target_laps, lap_length_m, layout_id),
            )
        await self.db.commit()

    async def delete_layout(self, layout_id: int):
        await self.db.execute(
            "DELETE FROM timing_layout_elements WHERE layout_id = ?",
            (layout_id,),
        )
        await self.db.execute(
            "DELETE FROM timing_layouts WHERE id = ?",
            (layout_id,),
        )
        await self.db.commit()


class TimingRaceRepository:
    """独立レース（timing_races）と通過イベント（timing_events）へのアクセス。"""

    def __init__(self, db: aiosqlite.Connection):
        self.db = db

    async def create_race(
        self,
        heat_tag: int | None,
        layout_id: int | None,
        target_laps: int,
        green_t_us: int | None,
        client_key: str | None = None,
        sample_note: str | None = None,
    ) -> int:
        # 冪等キー（任意）: GWが (device_id:boot_id:heat_tag) 等を送ってきた場合、
        # 200応答の消失→再送で同一ヒートのレースが二重生成される事故を防ぐ。
        # 旧ファーム（キーなし）は従来どおり毎回新規作成（後方互換）。
        if client_key:
            async with self.db.execute(
                "SELECT id FROM timing_races WHERE client_key = ?", (client_key,)
            ) as cur:
                row = await cur.fetchone()
            if row:
                return row["id"] if hasattr(row, "keys") else row[0]
        cur = await self.db.execute(
            "INSERT INTO timing_races (heat_tag, layout_id, target_laps, green_t_us, client_key, sample_note) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (heat_tag, layout_id, target_laps, green_t_us, client_key, sample_note),
        )
        await self.db.commit()
        return cur.lastrowid

    async def insert_events_batch(self, race_id: int, events: list) -> tuple[int, int]:
        """イベント一括挿入（単一トランザクション）。戻り値 (inserted, duplicate)。

        従来の insert_event はイベント1件ごとに commit しており、GWの1バッチ
        （最大数十件）で数十回の fsync が走っていた。バッチ全体を1Txにまとめ、
        入力検証（lane範囲・必須キー）もここで行う。
        """
        inserted = 0
        duplicate = 0
        try:
            for ev in events:
                lane = int(ev["lane"])
                if not (1 <= lane <= 8):
                    raise ValueError(f"lane out of range: {lane}")
                cur = await self.db.execute(
                    "INSERT OR IGNORE INTO timing_events "
                    "(race_id, device_id, src, src_boot_id, seq, lane, t_us, t_us_b, quality) "
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (race_id, str(ev["device_id"]), int(ev["src"]),
                     int(ev["src_boot_id"]), int(ev["seq"]), lane,
                     int(ev["t_us"]), ev.get("t_us_b"), int(ev.get("quality", 0))),
                )
                if cur.rowcount > 0:
                    inserted += 1
                else:
                    duplicate += 1
            await self.db.commit()
        except Exception:
            try:
                await self.db.rollback()
            except Exception:
                pass
            raise
        return inserted, duplicate

    async def set_green_t_us(self, race_id: int, green_t_us: int) -> int:
        """既存レースに緑時刻を後付けする（F1式へ切り替える）。

        GWは赤ボタン時点ではまだ緑時刻を持たないため、走行式として create_race し、
        緑を出した瞬間にこのメソッドで green_t_us を書き込む。これにより
        「緑の瞬間にレースを作り直す」割り切り（docs/19 残課題7）を解消する。
        戻り値: 更新した行数（0=該当レースなし）。
        """
        cur = await self.db.execute(
            "UPDATE timing_races SET green_t_us = ? WHERE id = ?",
            (green_t_us, race_id),
        )
        await self.db.commit()
        return cur.rowcount

    async def update_status(self, race_id: int, status: str) -> int:
        """レースの status（confirmed / needs_review）を更新する（I群 §24.71）。

        受信時判定の結果を書き込む。戻り値: 更新した行数。
        """
        cur = await self.db.execute(
            "UPDATE timing_races SET status = ? WHERE id = ?",
            (status, race_id),
        )
        await self.db.commit()
        return cur.rowcount

    async def get_race(self, race_id: int):
        # applied_ht_group_id はマイグレーション（timing_schema.py）で後から追加された列。
        # PIP の「反映済（ヒート○ …）」表示に必要なので取得するが、未適用の旧DBでも
        # レース取得自体は失敗させない（列なしSELECTへフォールバック）。
        _base = ("id, heat_tag, layout_id, target_laps, green_t_us, heat_id, "
                 "applied_group_id, created_at, status")
        try:
            async with self.db.execute(
                f"SELECT {_base}, applied_ht_group_id FROM timing_races WHERE id = ?",
                (race_id,),
            ) as cur:
                return await cur.fetchone()
        except Exception:
            async with self.db.execute(
                f"SELECT {_base} FROM timing_races WHERE id = ?",
                (race_id,),
            ) as cur:
                return await cur.fetchone()

    async def get_layout_json(self, race_id: int):
        """レース受信/作成時に固定したレイアウトのJSONスナップショットを返す。

        新しい build_race_result はこれを最優先で使う（後からレイアウトを編集しても
        そのレースは受信時点の構成で解釈する）。timing_races.layout_json 列が無い旧DBや
        未設定レースでは None を返し、呼び出し側は layout_id フォールバックに回る。
        （このメソッド欠落で build_race_result が全レース例外になり、計測結果が空になる事故を修正）
        """
        try:
            async with self.db.execute(
                "SELECT layout_json FROM timing_races WHERE id = ?", (race_id,)
            ) as cur:
                row = await cur.fetchone()
        except Exception:
            return None
        if not row:
            return None
        val = row["layout_json"] if hasattr(row, "keys") else row[0]
        return val or None

    async def list_races(self, limit: int = 50):
        async with self.db.execute(
            "SELECT id, heat_tag, layout_id, target_laps, green_t_us, applied_group_id, created_at, sample_note, status "
            "FROM timing_races ORDER BY id DESC LIMIT ?",
            (limit,),
        ) as cur:
            return await cur.fetchall()

    async def list_race_dates(self, limit: int = 60):
        """計測実績のある日付を新しい順に返す（絞り込みプルダウン用）。

        created_at は "YYYY-MM-DD HH:MM:SS" 形式なので日付部分で集計する。
        戻り値: [{"date": "2026-07-23", "n": 12}, ...]
        """
        async with self.db.execute(
            "SELECT substr(created_at,1,10) AS d, COUNT(*) AS n "
            "FROM timing_races GROUP BY d ORDER BY d DESC LIMIT ?",
            (limit,),
        ) as cur:
            rows = await cur.fetchall()
        return [{"date": r["d"], "n": int(r["n"])} for r in rows]

    async def list_races_by_date(self, date: str, limit: int = 500):
        """指定日（YYYY-MM-DD）のレースを新しい順に返す。"""
        async with self.db.execute(
            "SELECT id, heat_tag, layout_id, target_laps, green_t_us, applied_group_id, created_at, sample_note, status "
            "FROM timing_races WHERE substr(created_at,1,10) = ? "
            "ORDER BY id DESC LIMIT ?",
            (date, limit),
        ) as cur:
            return await cur.fetchall()

    async def list_races_between(self, date_from: str, date_to: str, limit: int = 5000):
        """期間（両端を含む）のレースを古い順に返す。ベスト集計用。

        created_at は "YYYY-MM-DD HH:MM:SS" 形式なので日付部分で比較する。
        """
        async with self.db.execute(
            "SELECT id, heat_tag, layout_id, target_laps, green_t_us, applied_group_id, created_at, sample_note, status "
            "FROM timing_races "
            "WHERE substr(created_at,1,10) >= ? AND substr(created_at,1,10) <= ? "
            "ORDER BY id ASC LIMIT ?",
            (date_from, date_to, limit),
        ) as cur:
            return await cur.fetchall()

    async def list_races_between_ts(self, ts_from: str, ts_to: str, limit: int = 2000):
        """作成日時の範囲（両端を含む）でレースを古い順に返す。

        ts_from / ts_to は created_at と同じ 'YYYY-MM-DD HH:MM:SS' 形式。
        「当日」を 09:00〜翌08:59 の24時間で扱うため、日付だけでなく時刻まで見る。
        固定長・ゼロ埋めの文字列なので、辞書順の比較で日時の比較になる。
        """
        async with self.db.execute(
            "SELECT id, heat_tag, layout_id, target_laps, green_t_us, applied_group_id, created_at, sample_note, status "
            "FROM timing_races WHERE created_at >= ? AND created_at <= ? "
            "ORDER BY id ASC LIMIT ?",
            (ts_from, ts_to, limit),
        ) as cur:
            return await cur.fetchall()

    async def delete_race(self, race_id: int) -> int:
        """レースを1件削除する（通過イベントも一緒に消える）。

        timing_events は ON DELETE CASCADE だが、既存の delete_layout と同じ流儀で
        明示的に消してから親を消す（PRAGMAの状態に依存しないようにするため）。
        戻り値: 削除した通過イベント件数（0でもレース自体は削除する）
        """
        async with self.db.execute(
            "SELECT COUNT(*) AS n FROM timing_events WHERE race_id = ?", (race_id,)
        ) as cur:
            row = await cur.fetchone()
        n_events = int(row["n"]) if row else 0

        await self.db.execute(
            "DELETE FROM timing_events WHERE race_id = ?", (race_id,)
        )
        await self.db.execute(
            "DELETE FROM timing_races WHERE id = ?", (race_id,)
        )
        await self.db.commit()
        return n_events

    async def insert_event(self, race_id: int, ev: dict) -> bool:
        """通過イベントを1件挿入。冪等キー（D12）で重複は無視。

        戻り値: True=新規挿入 / False=重複（既にある）
        ev: {device_id, src, src_boot_id, seq, lane, t_us, t_us_b?, quality?}
        """
        cur = await self.db.execute(
            "INSERT OR IGNORE INTO timing_events "
            "(race_id, device_id, src, src_boot_id, seq, lane, t_us, t_us_b, quality) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (
                race_id,
                str(ev["device_id"]),
                int(ev["src"]),
                int(ev["src_boot_id"]),
                int(ev["seq"]),
                int(ev["lane"]),
                int(ev["t_us"]),
                ev.get("t_us_b"),
                int(ev.get("quality", 0)),
            ),
        )
        await self.db.commit()
        return cur.rowcount > 0

    async def get_events(self, race_id: int):
        async with self.db.execute(
            "SELECT id, src, lane, t_us, t_us_b, quality, seq FROM timing_events "   # ★C11：id を含める（点除外の to_event_id 用）
            "WHERE race_id = ? ORDER BY t_us",
            (race_id,),
        ) as cur:
            return await cur.fetchall()
