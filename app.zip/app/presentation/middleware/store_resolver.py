"""
StoreResolverMiddleware（クラウド版のみ登録）。

役割:
  1. リクエスト先頭パスから店舗を判定する。
       /admin /view /static /logo /health /api /enter / favicon → 既定店舗（店舗1）
       /{slug}/...                                            → 該当店舗（slug一致）
       不明・無効スラッグ                                      → 404
  2. スラッグ付きの場合、scope の path から "/{slug}" を取り除き、root_path に
     "/{slug}" をセットする。これで既存ルーター（/admin/... 等）はそのまま動く。
  3. request.state.store と ContextVar(current_store) に解決した店舗をセットする。
  4. スラッグ付き店舗のレスポンスについてのみ、HTML本文とリダイレクト先(Location)中の
     絶対パス（/admin /view /static /logo /api /enter）へ "/{slug}" を前置する。
     → テンプレートの絶対パス（約120箇所）を書き換えずに、スラッグ配下で正しく動かす。

既定店舗（店舗1・スラッグなし）はパス書き換えを一切行わないため、従来挙動と完全に同一。
オンプレ版では add_store_resolver() が何もしないため影響なし。
"""
from __future__ import annotations

import os
import re
import secrets

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response, PlainTextResponse

from app import registry
from app.core.store_context import Store, current_store

# 既定店舗のアプリパス（これらが先頭ならスラッグ解決をスキップ）
_APP_PREFIXES = ("admin", "view", "static", "logo", "health", "api", "enter", "favicon")

# HTML本文中で前置対象にする絶対パス接頭辞
_REWRITE_RE = re.compile(r"([\"'`])(/(?:admin|view|static|logo|health|api|enter)\b)")

# 内部レンダリング（public_html の自己呼び出し）用の共有シークレット。
# 設定されている場合のみ x-internal-render-secret の一致を要求する。
# 未設定なら従来どおり x-internal-store-id をそのまま信頼する（後方互換）。
# 本番では設定し、リバースプロキシ側で両ヘッダを外部リクエストから除去することを推奨。
_INTERNAL_SECRET = os.environ.get("INTERNAL_RENDER_SECRET", "")


def _internal_header_trusted(request) -> bool:
    if not _INTERNAL_SECRET:
        return True  # 未設定：従来挙動を維持
    sig = request.headers.get("x-internal-render-secret", "")
    return bool(sig) and secrets.compare_digest(sig, _INTERNAL_SECRET)


def _first_segment(path: str) -> str:
    # "/store2/admin/" -> "store2"
    p = path.lstrip("/")
    return p.split("/", 1)[0] if p else ""


class StoreResolverMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        path = request.scope.get("path", "/")

        # 内部レンダリング（public_html が自分自身へ httpx で投げる観覧ページ生成）用の
        # バイパス。スラッグなしURL＋ヘッダで店舗を指定する。パス書き換えは行わない。
        internal_id = request.headers.get("x-internal-store-id")
        if internal_id and _internal_header_trusted(request):
            try:
                istore = registry.get_store_by_id(int(internal_id))
            except Exception:
                istore = None
            if istore is not None and istore.enabled:
                request.state.store = istore
                tok = current_store.set(istore)
                try:
                    return await call_next(request)
                finally:
                    current_store.reset(tok)

        seg = _first_segment(path)

        store: Store | None = None
        slug = ""

        if seg == "" or seg in _APP_PREFIXES:
            # 既定店舗（店舗1）
            store = registry.get_default_store()
        elif (_rw := self._word_rewrite(registry.get_default_store(), path)) is not None:
            # ドメイン直下 /<観覧語> や /<観覧語>/enter/<鍵語> を既定店舗の2語入口として扱う。
            # scope を内部ルート（/enter/__m4view__/… or /enter/__m4entry__/…）へ書き換える。
            store = registry.get_default_store()
            request.scope["path"] = _rw
            if "raw_path" in request.scope and request.scope["raw_path"]:
                try:
                    request.scope["raw_path"] = _rw.encode()
                except Exception:
                    pass
        else:
            # スラッグ候補
            store = registry.get_store_by_slug(seg)
            if store is None:
                return PlainTextResponse("404 Not Found: 不明な店舗です。", status_code=404)
            if not store.enabled:
                return PlainTextResponse("404 Not Found: この店舗は現在無効です。", status_code=404)
            slug = store.slug
            # /{slug}/static/... は scope 書き換えを行わない。
            # BaseHTTPMiddleware の scope 書き換えは Mount(StaticFiles) に届かず 404 に
            # なるため、main.py の専用ルート（/{slug}/static/{path}）にそのまま委譲する。
            # （store は解決済みなのでヘッダ等は通常どおり付く）
            _parts = path.lstrip("/").split("/")
            _second = _parts[1] if len(_parts) > 1 else ""
            if _second != "static":
                # scope から "/{slug}" を除去し root_path にセット
                stripped = path[len(f"/{slug}"):] or "/"
                # /<slug>/<観覧語>[/enter/<鍵語>] を2語入口として内部ルートへ委譲。
                _rw2 = self._word_rewrite(store, stripped)
                if _rw2 is not None:
                    stripped = _rw2
                request.scope["path"] = stripped
                request.scope["root_path"] = f"/{slug}"
                if "raw_path" in request.scope and request.scope["raw_path"]:
                    try:
                        request.scope["raw_path"] = request.scope["raw_path"][len(f"/{slug}".encode()):] or b"/"
                    except Exception:
                        pass
            else:
                # 書き換えしない場合でも、応答HTML前置(_rewrite_response)が
                # 二重前置しないよう slug は空に倒す（静的JSにHTML書き換えは不要）。
                slug = ""

        if store is None:
            return PlainTextResponse("500: 既定店舗が未初期化です。", status_code=500)

        # 利用時間制限（店舗2〜5・デモ/お試し用）。時間外は admin/view/参加者すべてブロック。
        if not registry.is_store_open(store):
            return self._blocked_response(store)

        request.state.store = store
        token = current_store.set(store)
        try:
            response = await call_next(request)
        finally:
            current_store.reset(token)

        # スラッグ付き店舗のみ、出力パスへ "/{slug}" を前置
        if slug:
            response = await self._rewrite_response(response, slug)
        return response

    def _word_rewrite(self, store, subpath: str):
        """店舗prefixを除いたサブパスが当日の2語URLなら内部ルートへ書き換えて返す。

          /<観覧語>              -> /enter/__m4view__/<観覧語>
          /<観覧語>/enter/<鍵語> -> /enter/__m4entry__/<観覧語>/<鍵語>

        当日の観覧語に一致しなければ None（＝通常のスラッグ解決や404に委ねる）。
        """
        try:
            from app.services import pub_gate
            if store is None:
                return None
            secret = pub_gate.secret_for(store)
            if not secret:
                return None
            epoch = pub_gate.get_epoch(pub_gate.db_path_for(store))
            parts = subpath.strip("/").split("/")
            if len(parts) == 1 and parts[0] and parts[0] not in _APP_PREFIXES:
                if pub_gate.verify_view_word(secret, epoch, parts[0]):
                    return "/enter/__m4view__/" + parts[0]
            elif len(parts) == 3 and parts[1] == "enter" and parts[0] and parts[2]:
                if pub_gate.verify_view_word(secret, epoch, parts[0]):
                    return "/enter/__m4entry__/" + parts[0] + "/" + parts[2]
            return None
        except Exception:
            return None

    async def _rewrite_response(self, response, slug: str):
        # --- リダイレクト先(Location)の前置 ---
        loc = response.headers.get("location")
        if loc and loc.startswith("/") and not loc.startswith(f"/{slug}/") and loc != f"/{slug}":
            response.headers["location"] = f"/{slug}{loc}"

        # --- HTML本文の前置（text/html のみ）---
        ctype = response.headers.get("content-type", "")
        if "text/html" not in ctype:
            return response

        body = b""
        async for chunk in response.body_iterator:
            body += chunk if isinstance(chunk, (bytes, bytearray)) else chunk.encode("utf-8")

        text = body.decode("utf-8", "ignore")
        # 置換が1件も発生しなければ、テキスト再構築を省いて元の body をそのまま返す
        # （text/html でもスラッグ前置の対象パスを含まないレスポンスは多いため）
        new_text, n = _REWRITE_RE.subn(lambda m: f"{m.group(1)}/{slug}{m.group(2)}", text)
        headers = dict(response.headers)
        headers.pop("content-length", None)  # 長さが変わり得るので再計算させる
        if n == 0:
            # 置換なし → テキスト再構築を省き、元の body をそのまま返す
            return Response(
                content=body,
                status_code=response.status_code,
                headers=headers,
                media_type="text/html",
            )
        text = new_text

        return Response(
            content=text,
            status_code=response.status_code,
            headers=headers,
            media_type="text/html",
        )

    def _blocked_response(self, store):
        """利用時間外の店舗へのアクセスに対して案内ページ（503）を返す。"""
        from html import escape
        name = escape(store.name or "")
        start = escape(store.access_start or "")
        end = escape(store.access_end or "")
        html = f"""<!doctype html>
<html lang="ja"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ただいまご利用いただけません</title>
<style>
  body{{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f4f5f7;
       display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;color:#2c3e50}}
  .box{{background:#fff;border-radius:12px;padding:32px 28px;max-width:420px;text-align:center;
        box-shadow:0 4px 18px rgba(0,0,0,.08)}}
  h1{{font-size:18px;margin:0 0 10px}}
  p{{font-size:14px;color:#636e72;line-height:1.6;margin:6px 0}}
  .time{{display:inline-block;margin-top:10px;font-size:15px;font-weight:bold;color:#2c3e50;
         background:#f4f5f7;padding:6px 14px;border-radius:8px}}
</style></head>
<body>
  <div class="box">
    <h1>🚧 ただいまご利用いただけません</h1>
    <p>{name} は現在ご利用時間外です。</p>
    <p>下記の時間帯にアクセスしてください。</p>
    <div class="time">{start} 〜 {end}</div>
  </div>
</body></html>"""
        return Response(content=html, status_code=503, media_type="text/html")


def add_store_resolver(app):
    """クラウド版のときだけ店舗リゾルバを登録する。"""
    from app.config import IS_CLOUD
    if not IS_CLOUD:
        return
    app.add_middleware(StoreResolverMiddleware)
